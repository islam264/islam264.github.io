<?php
// Is file ko 'Uzra' folder mein save karein
require 'common/config.php';

try {
    echo "<h2>⚙️ Creating Banners Table...</h2>";

    // 1. Banners Table Banana
    $sql = "CREATE TABLE IF NOT EXISTS banners (
        id INT AUTO_INCREMENT PRIMARY KEY,
        image VARCHAR(255) NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )";
    $conn->exec($sql);
    echo "<p style='color:green'>✅ 'banners' Table Created Successfully.</p>";

    echo "<hr><h3>🎉 Fix Complete!</h3>";
    echo "<a href='index.php' style='background:red; color:white; padding:15px 30px; text-decoration:none; border-radius:5px;'>Go to Home Page</a>";

} catch(PDOException $e) {
    echo "<h3 style='color:red'>Error: " . $e->getMessage() . "</h3>";
}
?>
