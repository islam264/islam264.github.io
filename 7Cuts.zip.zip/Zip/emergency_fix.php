<?php
// Is file ko 'Uzra' folder me save karein
require 'common/config.php';

echo "<html><body style='font-family:sans-serif; padding:20px; line-height:1.6;'>";
echo "<h2>🚑 Database Emergency Fixer</h2>";

try {
    // 1. Check & Fix MRP Column
    echo "Checking 'mrp' column... ";
    try {
        // Koshish karein select karne ki
        $conn->query("SELECT mrp FROM products LIMIT 1");
        echo "<span style='color:green; font-weight:bold;'>Available ✅</span><br>";
    } catch (Exception $e) {
        // Agar fail ho, matlab column nahi hai. Ab add karein.
        echo "<span style='color:red;'>Missing!</span> Adding now... ";
        try {
            $conn->exec("ALTER TABLE products ADD COLUMN mrp DECIMAL(10,2) DEFAULT 0");
            echo "<span style='color:blue; font-weight:bold;'>Added Successfully ✅</span><br>";
        } catch (Exception $ex) {
            echo "<br><span style='background:red; color:white; padding:5px;'>Failed to add MRP: " . $ex->getMessage() . "</span><br>";
        }
    }

    // 2. Check & Fix Sizes Column
    echo "Checking 'sizes' column... ";
    try {
        $conn->query("SELECT sizes FROM products LIMIT 1");
        echo "<span style='color:green; font-weight:bold;'>Available ✅</span><br>";
    } catch (Exception $e) {
        echo "<span style='color:red;'>Missing!</span> Adding now... ";
        try {
            $conn->exec("ALTER TABLE products ADD COLUMN sizes VARCHAR(255) DEFAULT ''");
            echo "<span style='color:blue; font-weight:bold;'>Added Successfully ✅</span><br>";
        } catch (Exception $ex) {
            echo "<br><span style='background:red; color:white; padding:5px;'>Failed to add Sizes: " . $ex->getMessage() . "</span><br>";
        }
    }

    // 3. Check & Fix Gallery Table
    echo "Checking 'product_gallery' table... ";
    try {
        $conn->query("SELECT 1 FROM product_gallery LIMIT 1");
        echo "<span style='color:green; font-weight:bold;'>Available ✅</span><br>";
    } catch (Exception $e) {
        echo "<span style='color:red;'>Missing!</span> Creating now... ";
        $sql = "CREATE TABLE IF NOT EXISTS product_gallery (
            id INT AUTO_INCREMENT PRIMARY KEY,
            product_id INT,
            image VARCHAR(255)
        )";
        $conn->exec($sql);
        echo "<span style='color:blue; font-weight:bold;'>Created Successfully ✅</span><br>";
    }

    echo "<hr><h3>✅ Fix Complete!</h3>";
    echo "<p>Ab neeche diye gaye button par click karke wapis product add karein.</p>";
    echo "<a href='admin/product.php' style='background:green; color:white; padding:15px 30px; text-decoration:none; border-radius:5px; font-weight:bold;'>Go to Add Product</a>";

} catch(PDOException $e) {
    echo "<h3 style='color:red'>Critical Error: " . $e->getMessage() . "</h3>";
    echo "<p>Check your config.php connection.</p>";
}
echo "</body></html>";
?>
