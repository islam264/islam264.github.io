<?php
require 'common/config.php';

try {
    echo "<h2>⚙️ Setting up Users Table...</h2>";

    $sql = "CREATE TABLE IF NOT EXISTS users (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(100) NOT NULL,
        email VARCHAR(100) NOT NULL UNIQUE,
        password VARCHAR(255) NOT NULL,
        phone VARCHAR(20),
        address TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )";
    
    $conn->exec($sql);
    
    echo "<h3 style='color:green'>✅ Users Table Created Successfully!</h3>";
    echo "<p>Ab customers Signup aur Login kar sakte hain.</p>";
    echo "<a href='login.php' style='background:red; color:white; padding:10px 20px; text-decoration:none; border-radius:5px;'>Go to Login Page</a>";

} catch(PDOException $e) {
    echo "<h3 style='color:red'>Error: " . $e->getMessage() . "</h3>";
}
?>
