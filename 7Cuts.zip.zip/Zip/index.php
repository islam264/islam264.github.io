<?php
require 'common/config.php';
include 'common/header.php';

// 1. Fetch Categories (cat_image fix ke sath)
$cats = $conn->query("SELECT * FROM categories ORDER BY id DESC")->fetchAll();

// 2. Search & Filter Logic
$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$sql = "SELECT * FROM products WHERE 1=1";
$params = [];
if(!empty($search)) {
    $sql .= " AND (name LIKE ? OR description LIKE ?)";
    $params[] = "%$search%";
    $params[] = "%$search%";
    $heading = "Results for '$search'";
} else {
    $heading = "Fresh Arrivals";
}
$sql .= " ORDER BY id DESC";
$stmt = $conn->prepare($sql);
$stmt->execute($params);
$products = $stmt->fetchAll();

// 3. Safe Fetch for Settings & Banners
$social = [];
$banners = [];
try {
    $stmt = $conn->query("SELECT * FROM settings WHERE id=1");
    if($stmt) $social = $stmt->fetch();

    $stmt = $conn->query("SELECT * FROM banners ORDER BY id DESC");
    if($stmt) $banners = $stmt->fetchAll();
} catch(Exception $e) { }
?>

<style>
    .reveal-element { opacity: 0; transform: translateY(20px); transition: opacity 0.8s ease-out, transform 0.8s ease-out; }
    .reveal-element.visible { opacity: 1; transform: translateY(0); }
    .scroll-snap-x { scroll-snap-type: x mandatory; }
    .snap-start { scroll-snap-align: start; }
    .active-scale:active { transform: scale(0.95); transition: transform 0.1s; }
    .no-scrollbar::-webkit-scrollbar { display: none; }
</style>

<div class="bg-cream min-h-screen pb-24 overflow-x-hidden">
    
    <div class="p-4 reveal-element">
        <?php if(count($banners) > 0): ?>
            <div class="relative w-full h-40 md:h-56 rounded-2xl overflow-hidden shadow-md group">
                <div id="slider" class="flex transition-transform duration-500 ease-in-out h-full">
                    <?php foreach($banners as $b): ?>
                    <div class="min-w-full h-full relative">
                        <img src="<?= getImg($b['image']) ?>" class="w-full h-full object-cover">
                        <div class="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent"></div>
                    </div>
                    <?php endforeach; ?>
                </div>
                <div class="absolute bottom-3 left-0 w-full flex justify-center gap-2">
                    <?php foreach($banners as $i => $b): ?>
                    <button onclick="goToSlide(<?= $i ?>)" class="w-2 h-2 rounded-full bg-white/50 hover:bg-white transition-all slider-dot" data-index="<?= $i ?>"></button>
                    <?php endforeach; ?>
                </div>
            </div>
        <?php else: ?>
            <div class="w-full h-40 md:h-56 bg-gradient-to-r from-red-800 to-red-600 rounded-2xl shadow-md flex items-center justify-between px-6 relative overflow-hidden">
                <div class="absolute inset-0 opacity-20 bg-[url('https://www.transparenttextures.com/patterns/food.png')]"></div>
                <div class="relative z-10 text-white">
                    <span class="bg-yellow-400 text-red-900 text-[10px] font-bold px-2 py-1 rounded mb-2 inline-block">FREE DELIVERY</span>
                    <h2 class="text-2xl font-black leading-tight">Fresh Cuts<br>Fast Delivery</h2>
                    <p class="text-xs opacity-90 mt-1">Order before 2 PM & get 10% OFF</p>
                </div>
                <div class="relative z-10">
                    <i class="fas fa-drumstick-bite text-6xl text-white opacity-80 rotate-12"></i>
                </div>
            </div>
        <?php endif; ?>
    </div>

    <div class="container mx-auto px-4 mb-6 reveal-element" style="transition-delay: 100ms;">
        <div class="flex items-center justify-between mb-3">
            <h3 class="font-bold text-base text-[#4A3B32]">Categories</h3>
            <a href="#" class="text-[10px] text-red-600 font-bold tracking-wide">VIEW ALL</a>
        </div>
        <?php if(count($cats) > 0): ?>
        <div class="flex overflow-x-auto space-x-4 no-scrollbar pb-2 scroll-snap-x">
            <?php foreach($cats as $c): ?>
            <a href="product.php?cat=<?= $c['id'] ?>" class="flex-shrink-0 flex flex-col items-center snap-start group w-16 active-scale">
                <div class="w-12 h-12 rounded-full p-0.5 bg-white shadow-sm border border-[#F0E6D2] group-hover:border-red-500 transition-all duration-300 relative overflow-hidden">
                    <img src="<?= getCatImg($c['cat_image']) ?>" class="w-full h-full object-cover rounded-full">
                </div>
                <span class="text-[10px] font-bold text-[#5D4037] mt-1.5 text-center truncate w-full group-hover:text-red-600 transition"><?= htmlspecialchars($c['name']) ?></span>
            </a>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>
    </div>

    <div class="container mx-auto px-4 mb-8">
        <h3 class="font-bold text-lg mb-4 text-[#4A3B32] reveal-element" style="transition-delay: 200ms;"><?= htmlspecialchars($heading) ?></h3>
        <?php if(count($products) > 0): ?>
        <div class="grid grid-cols-2 md:grid-cols-4 gap-3">
            <?php foreach($products as $index => $p): 
                $delay = ($index % 6) * 100;
                
                $imgSrc = $p['image'];
                if(strpos($imgSrc, ',') !== false) {
                    $imgArray = explode(',', $imgSrc);
                    $imgSrc = $imgArray[0]; 
                }
                $finalImg = getImg(trim($imgSrc));
            ?>
            <div class="reveal-element" style="transition-delay: <?= $delay ?>ms;">
                <div class="bg-white rounded-xl shadow-sm hover:shadow-md overflow-hidden border border-[#F3EFE0] flex flex-col h-full relative transition-shadow duration-300">
                    <a href="product_detail.php?id=<?= $p['id'] ?>" class="h-44 bg-white p-2 relative flex items-center justify-center overflow-hidden">
                        <img src="<?= $finalImg ?>" class="w-full h-full object-contain hover:scale-105 transition-transform duration-500">
                    </a>
                    <div class="p-3 flex-1 flex flex-col">
                        <h4 class="font-bold text-xs text-[#3E2723] line-clamp-2 leading-tight mb-1"><?= htmlspecialchars($p['name']) ?></h4>
                        <div class="mt-auto flex items-center justify-between">
                            <span class="text-sm font-bold text-[#D32F2F]">₹<?= number_format($p['price']) ?></span>
                            <button onclick="addToCart(<?= $p['id'] ?>)" class="w-7 h-7 rounded-lg border border-red-100 bg-red-50 text-red-600 flex items-center justify-center hover:bg-red-600 hover:text-white transition-all shadow-sm active:scale-90">
                                <i class="fas fa-plus text-[10px]"></i>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        <?php else: ?>
            <div class="text-center py-16 bg-white rounded-2xl shadow-sm mx-4 border border-[#F3EFE0]"><p class="text-xs text-gray-500">No products found.</p></div>
        <?php endif; ?>
    </div>

    <div class="container mx-auto px-4 mb-8 reveal-element">
        <h3 class="font-bold text-sm text-[#4A3B32] mb-3 uppercase tracking-wider">Connect & Assurance</h3>
        <div class="grid grid-cols-4 gap-2">
            <a href="policies.php?page=shipping" class="bg-white p-2 rounded-lg border border-[#F0E6D2] flex flex-col items-center text-center shadow-sm active:scale-95 transition h-20 justify-center">
                <i class="fas fa-shipping-fast text-red-500 text-lg mb-1"></i><span class="text-[8px] font-bold text-gray-600 leading-tight">Fast<br>Delivery</span>
            </a>
            <a href="policies.php?page=privacy" class="bg-white p-2 rounded-lg border border-[#F0E6D2] flex flex-col items-center text-center shadow-sm active:scale-95 transition h-20 justify-center">
                <i class="fas fa-shield-alt text-green-500 text-lg mb-1"></i><span class="text-[8px] font-bold text-gray-600 leading-tight">100%<br>Secure</span>
            </a>
            <?php if(!empty($social['instagram'])): ?>
            <a href="<?= $social['instagram'] ?>" target="_blank" class="bg-white p-2 rounded-lg border border-[#F0E6D2] flex flex-col items-center text-center shadow-sm active:scale-95 transition h-20 justify-center">
                <i class="fab fa-instagram text-pink-600 text-xl mb-1"></i><span class="text-[8px] font-bold text-gray-600 leading-tight">Follow<br>Us</span>
            </a>
            <?php endif; ?>
            <?php if(!empty($social['whatsapp'])): ?>
            <a href="https://wa.me/<?= $social['whatsapp'] ?>" target="_blank" class="bg-white p-2 rounded-lg border border-[#F0E6D2] flex flex-col items-center text-center shadow-sm active:scale-95 transition h-20 justify-center">
                <i class="fab fa-whatsapp text-green-600 text-xl mb-1"></i><span class="text-[8px] font-bold text-gray-600 leading-tight">WhatsApp<br>Chat</span>
            </a>
            <?php endif; ?>
        </div>
    </div>

    <div class="bg-white border-t border-[#F0E6D2] p-4 text-center reveal-element">
        <h2 class="text-lg font-black text-red-700 mb-1 tracking-tighter" style="font-family: sans-serif;">7Cuts</h2>
        <p class="text-[9px] text-gray-300">© 2024 7Cuts. All rights reserved.</p>
    </div>

</div>

<script>
    // Slider Logic
    let currentIndex = 0;
    const slides = document.querySelectorAll('#slider > div');
    const totalSlides = slides.length;
    const slider = document.getElementById('slider');

    function updateSlider() {
        if(totalSlides === 0) return;
        slider.style.transform = `translateX(-${currentIndex * 100}%)`;
    }
    function nextSlide() { currentIndex = (currentIndex + 1) % totalSlides; updateSlider(); }
    if(totalSlides > 1) { setInterval(nextSlide, 3000); updateSlider(); }

    // Animation
    document.addEventListener("DOMContentLoaded", function() {
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('visible');
                    observer.unobserve(entry.target); 
                }
            });
        }, { threshold: 0.1 });
        document.querySelectorAll('.reveal-element').forEach(el => observer.observe(el));
    });

    // Add To Cart
    async function addToCart(pid) {
        try {
            const res = await fetch('cart.php', {
                method: 'POST',
                headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                body: `action=add&pid=${pid}&qty=1`
            });
            const data = await res.json();
            if(data.success) location.reload();
        } catch(e) { console.error(e); }
    }
</script>

<?php include 'common/bottom.php'; ?>
