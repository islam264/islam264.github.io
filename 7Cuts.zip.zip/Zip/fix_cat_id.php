<?php
require 'common/config.php';

try {
    echo "<h2>⚙️ Fixing Database Column...</h2>";

    // 1. Check karein ki kya 'category_id' naam ka column hai?
    $check = $conn->query("SHOW COLUMNS FROM products LIKE 'category_id'");
    
    if($check->rowCount() > 0) {
        // Agar hai, to usko rename karke 'cat_id' kar do (Data safe rahega)
        $conn->exec("ALTER TABLE products CHANGE category_id cat_id INT(11)");
        echo "<h3 style='color:green'>✅ Fixed! Renamed 'category_id' to 'cat_id'.</h3>";
    } else {
        // Agar wo bhi nahi hai, to check karo 'cat_id' hai ya nahi
        $check2 = $conn->query("SHOW COLUMNS FROM products LIKE 'cat_id'");
        if($check2->rowCount() == 0) {
            // Agar dono nahi hain, to naya bana do
            $conn->exec("ALTER TABLE products ADD COLUMN cat_id INT(11)");
            echo "<h3 style='color:green'>✅ Fixed! Created missing column 'cat_id'.</h3>";
        } else {
            echo "<h3 style='color:blue'>Info: 'cat_id' already exists. Everything looks good.</h3>";
        }
    }

    echo "<br><hr><a href='admin/product.php' style='background:red; color:white; padding:10px 20px; text-decoration:none; border-radius:5px;'>Go to Admin Products</a>";

} catch(PDOException $e) {
    echo "<h3 style='color:red'>Error: " . $e->getMessage() . "</h3>";
}
?>
