<?php
require 'common/config.php';

if(!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

include 'common/header.php';

// Fetch Orders
$uid = $_SESSION['user_id'];
$stmt = $conn->prepare("SELECT * FROM orders WHERE user_id = ? ORDER BY id DESC");
$stmt->execute([$uid]);
$orders = $stmt->fetchAll();
?>

<style>
    /* Animation Styles */
    .reveal-element { opacity: 0; transform: translateY(20px); transition: opacity 0.6s ease-out, transform 0.6s ease-out; }
    .reveal-element.visible { opacity: 1; transform: translateY(0); }
</style>

<div class="bg-cream min-h-screen pb-24">
    <div class="container mx-auto px-4 pt-6">
        
        <h1 class="text-2xl font-black text-[#4A3B32] mb-6 reveal-element">My Orders</h1>

        <?php if(count($orders) > 0): ?>
            <div class="space-y-4">
                <?php 
                $delay = 0;
                foreach($orders as $o): 
                    $delay += 100;
                    
                    // Status Colors
                    $statusColor = 'bg-yellow-100 text-yellow-700';
                    if($o['status'] == 'Delivered') $statusColor = 'bg-green-100 text-green-700';
                    if($o['status'] == 'Cancelled') $statusColor = 'bg-red-100 text-red-700';
                    if($o['status'] == 'Dispatched') $statusColor = 'bg-blue-100 text-blue-700';
                ?>
                <div class="reveal-element bg-white p-5 rounded-xl shadow-sm border border-[#F0E6D2] hover:shadow-md transition duration-300" style="transition-delay: <?= $delay ?>ms;">
                    <div class="flex justify-between items-start mb-3">
                        <div>
                            <span class="text-xs font-bold text-gray-400 uppercase tracking-wide">Order #<?= $o['id'] ?></span>
                            <h3 class="text-lg font-black text-[#3E2723]">₹<?= $o['total_amount'] ?></h3>
                        </div>
                        <span class="px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-wide <?= $statusColor ?>">
                            <?= $o['status'] ?>
                        </span>
                    </div>

                    <div class="text-xs text-gray-500 flex items-center gap-2 mb-4">
                        <i class="far fa-clock"></i>
                        <?= date('d M Y, h:i A', strtotime($o['created_at'])) ?>
                    </div>

                    <div class="border-t border-dashed border-gray-200 pt-3 flex justify-between items-center">
                        <p class="text-xs text-gray-500 max-w-[70%] truncate">
                            <i class="fas fa-map-marker-alt mr-1"></i> <?= htmlspecialchars($o['address']) ?>
                        </p>
                        <button class="text-red-600 font-bold text-xs hover:underline">View Details</button>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <div class="text-center py-20 reveal-element">
                <div class="w-24 h-24 bg-white rounded-full flex items-center justify-center mx-auto mb-4 border border-[#F0E6D2]">
                    <i class="fas fa-receipt text-3xl text-gray-300"></i>
                </div>
                <h2 class="text-lg font-bold text-[#4A3B32]">No orders yet</h2>
                <p class="text-gray-400 text-sm mt-1">Start ordering delicious meat today!</p>
            </div>
        <?php endif; ?>

    </div>
</div>

<script>
    document.addEventListener("DOMContentLoaded", function() {
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('visible');
                    observer.unobserve(entry.target); 
                }
            });
        }, { threshold: 0.1 });
        document.querySelectorAll('.reveal-element').forEach(el => observer.observe(el));
    });
</script>

<?php include 'common/bottom.php'; ?>
