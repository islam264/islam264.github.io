<?php
require 'common/config.php';

try {
    echo "<div style='font-family:sans-serif; padding:20px; line-height:1.6;'>";
    echo "<h2 style='color:#333;'>🛠️ Project Database Auto-Fixer</h2>";

    // 1. Orders table mein payment aur address columns add karna
    $sql_orders = "ALTER TABLE orders 
        ADD COLUMN IF NOT EXISTS payment_method VARCHAR(50) DEFAULT 'COD',
        ADD COLUMN IF NOT EXISTS txn_id VARCHAR(100) DEFAULT NULL,
        ADD COLUMN IF NOT EXISTS city VARCHAR(100) DEFAULT NULL,
        ADD COLUMN IF NOT EXISTS state VARCHAR(100) DEFAULT NULL,
        ADD COLUMN IF NOT EXISTS pincode VARCHAR(10) DEFAULT NULL";
    
    $conn->exec($sql_orders);
    echo "<p style='color:green;'>✅ Success: Orders table updated (QR & Address fields).</p>";

    // 2. Settings table mein qr_code column add karna
    $sql_settings = "ALTER TABLE settings 
        ADD COLUMN IF NOT EXISTS qr_code VARCHAR(255) DEFAULT 'assets/my_qr.jpg'";
    
    $conn->exec($sql_settings);
    echo "<p style='color:green;'>✅ Success: Settings table updated (Admin QR field).</p>";

    echo "<hr>";
    echo "<h3 style='color:#007bff;'>🚀 All Fixes Applied!</h3>";
    echo "<p>Ab aapka Checkout page aur Admin Settings bina kisi error ke chalenge.</p>";
    echo "<a href='cart.php' style='background:#dc2626; color:white; padding:10px 20px; text-decoration:none; border-radius:8px;'>Go to Checkout</a>";
    echo "</div>";

} catch(PDOException $e) {
    echo "<h3 style='color:red;'>❌ Error: " . $e->getMessage() . "</h3>";
}
?>
