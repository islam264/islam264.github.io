<?php
require 'common/config.php';

try {
    echo "<h2>⚙️ Adding Social Media Features...</h2>";

    // 1. Settings Table Banana
    $sql = "CREATE TABLE IF NOT EXISTS settings (
        id INT AUTO_INCREMENT PRIMARY KEY,
        whatsapp VARCHAR(255),
        instagram VARCHAR(255),
        facebook VARCHAR(255),
        youtube VARCHAR(255)
    )";
    $conn->exec($sql);
    echo "✅ Settings Table Created.<br>";

    // 2. Default Row Insert karna (Taaki hum update kar sakein)
    $stmt = $conn->query("SELECT * FROM settings WHERE id=1");
    if($stmt->rowCount() == 0) {
        $conn->exec("INSERT INTO settings (id, whatsapp, instagram, facebook, youtube) VALUES (1, '', '', '', '')");
        echo "✅ Default Settings Row Added.<br>";
    }

    echo "<hr><h3>🎉 Done! Now create Admin Setting Page.</h3>";
    echo "<a href='admin/index.php'>Go to Admin</a>";

} catch(PDOException $e) {
    echo "Error: " . $e->getMessage();
}
?>
