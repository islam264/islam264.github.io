<?php
require 'common/config.php';

try {
    echo "<div style='font-family:sans-serif; padding:20px;'>";
    echo "<h2 style='color:#333;'>⚙️ Updating Database for Payments...</h2>";

    // 1. payment_method column check aur add karna
    $conn->exec("ALTER TABLE orders ADD COLUMN IF NOT EXISTS payment_method VARCHAR(50) DEFAULT 'COD'");
    
    // 2. txn_id column check aur add karna (Transaction ID ke liye)
    $conn->exec("ALTER TABLE orders ADD COLUMN IF NOT EXISTS txn_id VARCHAR(100) DEFAULT NULL");
    
    echo "<h3 style='color:green;'>✅ Success! Database table updated.</h3>";
    echo "<p>Ab aap QR Code aur COD dono options use kar sakte hain.</p>";
    echo "<br><a href='cart.php' style='background:#dc2626; color:white; padding:10px 20px; text-decoration:none; border-radius:8px;'>Go to Cart</a>";
    echo "</div>";

} catch(PDOException $e) {
    // Agar columns pehle se hain to error handling
    if($e->getCode() == "42S21") {
        echo "<h3 style='color:blue;'>ℹ️ Database already updated.</h3>";
        echo "<a href='cart.php'>Go to Cart</a>";
    } else {
        echo "<h3 style='color:red;'>❌ Error: " . $e->getMessage() . "</h3>";
    }
}
?>
