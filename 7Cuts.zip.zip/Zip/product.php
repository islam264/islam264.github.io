<?php
require 'common/config.php';
include 'common/header.php';

$cat_id = isset($_GET['cat']) ? intval($_GET['cat']) : 0;
$search = isset($_GET['search']) ? trim($_GET['search']) : '';

// Sort Logic
$sort = $_GET['sort'] ?? 'new';
$orderSQL = "ORDER BY id DESC";
if($sort == 'price_low') $orderSQL = "ORDER BY price ASC";
if($sort == 'price_high') $orderSQL = "ORDER BY price DESC";

// Main Query Logic
$params = [];
$sql = "SELECT * FROM products WHERE 1=1"; 

// 1. Category Filter Logic
if($cat_id > 0) {
    $sql .= " AND category_id = ?";
    $params[] = $cat_id;
    
    // Category Name fetch karte waqt error handle karein
    $catQuery = $conn->prepare("SELECT name FROM categories WHERE id = ?");
    $catQuery->execute([$cat_id]);
    $catName = $catQuery->fetchColumn() ?: "Category";
} else {
    $catName = "Fresh Arrivals";
}

// 2. Search Logic
if(!empty($search)) {
    $sql .= " AND (name LIKE ? OR description LIKE ?)";
    $params[] = "%$search%";
    $params[] = "%$search%";
    $catName = "Results for: '$search'";
}

// Final Execution
$sql .= " $orderSQL";
$stmt = $conn->prepare($sql);
$stmt->execute($params);
$products = $stmt->fetchAll();
?>

<div class="container mx-auto px-4 mt-4 mb-24 min-h-[60vh]">
    <div class="flex justify-between items-center mb-6">
        <div>
            <h2 class="text-lg font-black text-gray-800 uppercase tracking-tight"><?= htmlspecialchars($catName) ?></h2>
            <p class="text-[10px] text-gray-400 font-bold uppercase tracking-widest"><?= count($products) ?> Items Found</p>
        </div>
        
        <select onchange="applySort(this.value)" class="border-2 border-gray-100 rounded-xl px-3 py-2 text-[10px] font-bold bg-white outline-none focus:border-red-500 transition-all uppercase">
            <option value="new" <?= $sort=='new'?'selected':'' ?>>Newest</option>
            <option value="price_low" <?= $sort=='price_low'?'selected':'' ?>>Price: Low to High</option>
            <option value="price_high" <?= $sort=='price_high'?'selected':'' ?>>Price: High to Low</option>
        </select>
    </div>

    <?php if(count($products) > 0): ?>
    <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
        <?php foreach($products as $p): ?>
        <div class="bg-white rounded-3xl shadow-sm border border-gray-100 overflow-hidden flex flex-col group transition-all active:scale-[0.98]">
            <a href="product_detail.php?id=<?= $p['id'] ?>" class="h-44 overflow-hidden bg-white p-4 relative flex items-center justify-center">
                <img src="<?= getImg($p['image']) ?>" class="max-h-full max-w-full object-contain group-hover:scale-110 transition-transform duration-500">
                <?php if(isset($p['stock']) && $p['stock'] <= 0): ?>
                    <div class="absolute inset-0 bg-white/80 backdrop-blur-[2px] flex items-center justify-center text-[10px] font-black text-red-600 uppercase">OUT OF STOCK</div>
                <?php endif; ?>
            </a>
            <div class="p-4 flex-1 flex flex-col justify-between bg-gray-50/50">
                <div>
                    <h4 class="font-bold text-xs text-gray-700 line-clamp-2 leading-tight uppercase tracking-tight"><?= htmlspecialchars($p['name']) ?></h4>
                    <p class="font-black text-red-600 mt-2 text-sm tracking-tighter">₹<?= number_format($p['price']) ?></p>
                </div>
                <a href="product_detail.php?id=<?= $p['id'] ?>" class="mt-4 block w-full text-center bg-white border border-gray-200 text-gray-800 text-[10px] font-black py-3 rounded-2xl hover:bg-red-600 hover:text-white hover:border-red-600 transition-all uppercase tracking-widest">
                    View Details
                </a>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
    <?php else: ?>
        <div class="text-center py-20 bg-white rounded-[2.5rem] border border-dashed border-gray-200">
            <div class="w-20 h-20 bg-gray-50 rounded-full flex items-center justify-center mx-auto mb-4">
                <i class="fas fa-search text-2xl text-gray-300"></i>
            </div>
            <h3 class="text-sm font-black text-gray-800 uppercase tracking-tight">No products found</h3>
            <p class="text-gray-400 text-[10px] font-bold uppercase mt-1">Try another category or search term</p>
            <a href="product.php" class="inline-block mt-6 px-8 py-3 bg-red-600 text-white rounded-full font-black text-[10px] uppercase tracking-widest shadow-lg shadow-red-200">Show All Products</a>
        </div>
    <?php endif; ?>
</div>

<script>
    function applySort(sortVal) {
        const urlParams = new URLSearchParams(window.location.search);
        urlParams.set('sort', sortVal);
        window.location.search = urlParams.toString();
    }
</script>

<?php include 'common/bottom.php'; ?>
