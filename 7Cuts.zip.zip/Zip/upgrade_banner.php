<?php
require 'common/config.php';

try {
    echo "<h2>⚙️ Setting up Banners Table...</h2>";

    $conn->exec("CREATE TABLE IF NOT EXISTS banners (
        id INT AUTO_INCREMENT PRIMARY KEY,
        image VARCHAR(255) NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )");
    
    echo "✅ Banners Table Created Successfully.<br>";
    echo "<hr><h3>🎉 Done!</h3> <a href='admin/index.php'>Go to Admin</a>";

} catch(PDOException $e) {
    echo "Error: " . $e->getMessage();
}
?>
