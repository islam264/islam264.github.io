<?php
require 'common/config.php';
if(!isset($_SESSION['user_id'])) header("Location: login.php");
if(empty($_SESSION['cart'])) header("Location: index.php");

// Fetch User Data for Auto-fill
$uid = $_SESSION['user_id'];
$stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$uid]);
$user = $stmt->fetch();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user_id = $_SESSION['user_id'];
    
    // Combine Address Parts into a single string for Database
    $full_name = $_POST['full_name'];
    $street = $_POST['street'];
    $city = $_POST['city'];
    $state = $_POST['state'];
    $pin = $_POST['pin'];
    $phone = $_POST['phone'];
    
    // Format: "Name | Address, City, State - PIN | Phone: ..."
    $final_address = "$full_name | $street, $city, $state - $pin | Phone: $phone";
    
    $total = 0;
    
    // Calculate Total
    $ids = implode(',', array_keys($_SESSION['cart']));
    $products = $conn->query("SELECT * FROM products WHERE id IN ($ids)")->fetchAll(PDO::FETCH_ASSOC);
    foreach($products as $p) {
        $total += $p['price'] * $_SESSION['cart'][$p['id']];
    }

    try {
        $conn->beginTransaction();
        // Insert Order
        $stmt = $conn->prepare("INSERT INTO orders (user_id, total_amount, address, payment_method) VALUES (?, ?, ?, 'COD')");
        $stmt->execute([$user_id, $total, $final_address]);
        $order_id = $conn->lastInsertId();

        // Insert Items
        $stmtItem = $conn->prepare("INSERT INTO order_items (order_id, product_id, quantity, price) VALUES (?, ?, ?, ?)");
        foreach($products as $p) {
            $qty = $_SESSION['cart'][$p['id']];
            $stmtItem->execute([$order_id, $p['id'], $qty, $p['price']]);
        }

        $conn->commit();
        unset($_SESSION['cart']);
        header("Location: order.php");
        exit;
    } catch(Exception $e) {
        $conn->rollBack();
        die("Order Failed: " . $e->getMessage());
    }
}

include 'common/header.php';
?>

<div class="bg-gray-50 min-h-screen pb-24">
    <div class="container mx-auto px-4 pt-6">
        
        <div class="flex items-center gap-3 mb-6">
            <div class="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center text-blue-600">
                <i class="fas fa-file-invoice text-lg"></i>
            </div>
            <h2 class="text-xl font-bold text-gray-800">BILLING DETAILS</h2>
        </div>

        <form method="POST" class="space-y-5">
            
            <div>
                <label class="block text-gray-700 font-bold mb-2 text-sm">Full Name <span class="text-red-500">*</span></label>
                <div class="relative">
                    <div class="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                        <i class="fas fa-user text-blue-500 text-lg"></i>
                    </div>
                    <input type="text" name="full_name" value="<?= htmlspecialchars($user['name']) ?>" 
                           class="w-full pl-12 pr-4 py-3.5 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent shadow-sm text-gray-700 font-medium" 
                           placeholder="Enter your name" required>
                </div>
            </div>

            <div>
                <label class="block text-gray-700 font-bold mb-2 text-sm">Street Address <span class="text-red-500">*</span></label>
                <div class="relative">
                    <div class="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                        <i class="fas fa-home text-blue-500 text-lg"></i>
                    </div>
                    <input type="text" name="street" 
                           class="w-full pl-12 pr-4 py-3.5 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent shadow-sm text-gray-700 font-medium" 
                           placeholder="House number and street name" required>
                </div>
            </div>

            <div>
                <label class="block text-gray-700 font-bold mb-2 text-sm">Town / City <span class="text-red-500">*</span></label>
                <div class="relative">
                    <div class="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                        <i class="fas fa-building text-blue-500 text-lg"></i>
                    </div>
                    <input type="text" name="city" 
                           class="w-full pl-12 pr-4 py-3.5 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent shadow-sm text-gray-700 font-medium" 
                           placeholder="Enter City" required>
                </div>
            </div>

            <div>
                <label class="block text-gray-700 font-bold mb-2 text-sm">State <span class="text-red-500">*</span></label>
                <div class="relative">
                    <div class="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                        <i class="fas fa-map text-blue-500 text-lg"></i>
                    </div>
                    <select name="state" class="w-full pl-12 pr-10 py-3.5 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent shadow-sm text-gray-700 font-medium appearance-none bg-white" required>
                        <option value="Delhi">Delhi</option>
                        <option value="Maharashtra">Maharashtra</option>
                        <option value="Karnataka">Karnataka</option>
                        <option value="Uttar Pradesh">Uttar Pradesh</option>
                        <option value="Haryana">Haryana</option>
                        <option value="Punjab">Punjab</option>
                        <option value="Other">Other</option>
                    </select>
                    <div class="absolute inset-y-0 right-0 pr-4 flex items-center pointer-events-none">
                        <i class="fas fa-chevron-down text-gray-400"></i>
                    </div>
                </div>
            </div>

            <div>
                <label class="block text-gray-700 font-bold mb-2 text-sm">PIN Code <span class="text-red-500">*</span></label>
                <div class="relative">
                    <div class="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                        <i class="fas fa-map-pin text-blue-500 text-lg"></i>
                    </div>
                    <input type="tel" name="pin" maxlength="6"
                           class="w-full pl-12 pr-4 py-3.5 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent shadow-sm text-gray-700 font-medium" 
                           placeholder="1100XX" required>
                </div>
            </div>

            <div>
                <label class="block text-gray-700 font-bold mb-2 text-sm">Phone <span class="text-red-500">*</span></label>
                <div class="relative">
                    <div class="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                        <i class="fas fa-phone-alt text-blue-500 text-lg"></i>
                    </div>
                    <input type="tel" name="phone" value="<?= htmlspecialchars($user['phone']) ?>" 
                           class="w-full pl-12 pr-4 py-3.5 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent shadow-sm text-gray-700 font-medium" 
                           placeholder="Enter Phone Number" required>
                </div>
            </div>

            <div>
                <label class="block text-gray-700 font-bold mb-2 text-sm">Email Address <span class="text-red-500">*</span></label>
                <div class="relative">
                    <div class="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                        <i class="fas fa-envelope text-blue-500 text-lg"></i>
                    </div>
                    <input type="email" name="email" value="<?= htmlspecialchars($user['email']) ?>" readonly
                           class="w-full pl-12 pr-4 py-3.5 border border-gray-300 rounded-xl bg-gray-100 text-gray-500 font-medium cursor-not-allowed">
                </div>
            </div>

            <div class="mt-6 p-4 bg-white rounded-xl border border-gray-200 shadow-sm flex items-center justify-between">
                <div class="flex items-center gap-3">
                    <div class="w-10 h-10 rounded-full bg-green-100 flex items-center justify-center text-green-600">
                        <i class="fas fa-money-bill-wave"></i>
                    </div>
                    <div>
                        <p class="font-bold text-gray-800">Cash on Delivery</p>
                        <p class="text-xs text-gray-500">Pay when you receive</p>
                    </div>
                </div>
                <i class="fas fa-check-circle text-green-500 text-xl"></i>
            </div>

            <button type="submit" class="w-full bg-red-600 text-white py-4 rounded-xl font-bold text-lg shadow-lg hover:bg-red-700 transition mt-4">
                PLACE ORDER
            </button>
        </form>
    </div>
</div>

<script>
    // Hide Global Bottom Nav to prevent overlap with big form
    document.addEventListener("DOMContentLoaded", function() {
        const globalNav = document.querySelector('nav.fixed.bottom-0');
        if(globalNav) {
            globalNav.style.display = 'none'; 
        }
    });
</script>

<?php include 'common/bottom.php'; ?>
