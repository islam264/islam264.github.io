<?php
ob_start();
require 'common/config.php';

// Login Check
if(!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    
    $user_id = $_SESSION['user_id'];
    $name = trim($_POST['name']);
    $phone = trim($_POST['phone']);
    
    // Detailed Address Fields
    $city = $_POST['city'] ?? '';
    $state = $_POST['state'] ?? '';
    $pincode = $_POST['pincode'] ?? '';
    $street = $_POST['address'] ?? '';
    $full_address = $street . ", " . $city . ", " . $state . " - " . $pincode;

    $total_amount = $_POST['total_amount'];
    $payment_method = $_POST['payment_method']; 
    // Transaction ID handling for online payments
    $txn_id = !empty($_POST['txn_id']) ? $_POST['txn_id'] : NULL; 
    
    $status = 'Pending'; // Default status

    try {
        $conn->beginTransaction();

        // 1. Order save karna (Database Columns Match Fix)
        $sql = "INSERT INTO orders (user_id, name, phone, address, total_amount, status, payment_method, txn_id, created_at) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW())";
        
        $stmt = $conn->prepare($sql);
        $stmt->execute([$user_id, $name, $phone, $full_address, $total_amount, $status, $payment_method, $txn_id]);
        
        $order_id = $conn->lastInsertId();

        // 2. Order items insert karna
        if(isset($_SESSION['cart']) && !empty($_SESSION['cart'])) {
            $ids = implode(',', array_keys($_SESSION['cart']));
            $products = $conn->query("SELECT * FROM products WHERE id IN ($ids)")->fetchAll();

            $stmtItem = $conn->prepare("INSERT INTO order_items (order_id, product_id, quantity, price) VALUES (?, ?, ?, ?)");

            foreach($products as $p) {
                $qty = $_SESSION['cart'][$p['id']];
                $stmtItem->execute([$order_id, $p['id'], $qty, $p['price']]);
            }
        }

        $conn->commit();

        // 3. Success Message & Redirect
        unset($_SESSION['cart']);
        echo "<script>
            alert('Order Placed Successfully! Order ID: #$order_id');
            window.location.href = 'index.php';
        </script>";

    } catch(Exception $e) {
        $conn->rollBack();
        // Database column error catch
        die("Error: " . $e->getMessage()); 
    }
} else {
    header("Location: index.php");
}
?>
