<?php
require 'common/config.php';

// Agar user pehle se logged in hai to home bhej do
if(isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit;
}

$error = "";
$success = "";

// 1. HANDLE FORM SUBMISSION
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    
    // --- LOGIN LOGIC ---
    if (isset($_POST['action']) && $_POST['action'] == 'login') {
        $email = trim($_POST['email']);
        $password = trim($_POST['password']);

        if(!empty($email) && !empty($password)) {
            $stmt = $conn->prepare("SELECT * FROM users WHERE email = ?");
            $stmt->execute([$email]);
            $user = $stmt->fetch();

            // Password Verify (Hash check)
            if ($user && password_verify($password, $user['password'])) {
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['user_name'] = $user['name'];
                header("Location: index.php");
                exit;
            } else {
                $error = "Invalid email or password!";
            }
        } else {
            $error = "Please fill all fields.";
        }
    }

    // --- SIGNUP LOGIC ---
    if (isset($_POST['action']) && $_POST['action'] == 'signup') {
        $name = trim($_POST['name']);
        $email = trim($_POST['email']);
        $password = trim($_POST['password']);

        if(!empty($name) && !empty($email) && !empty($password)) {
            // Check duplicate email
            $check = $conn->prepare("SELECT id FROM users WHERE email = ?");
            $check->execute([$email]);
            
            if($check->rowCount() > 0) {
                $error = "Email already registered. Please Login.";
            } else {
                // Insert New User
                $hashedPass = password_hash($password, PASSWORD_DEFAULT);
                $stmt = $conn->prepare("INSERT INTO users (name, email, password) VALUES (?, ?, ?)");
                if($stmt->execute([$name, $email, $hashedPass])) {
                    $success = "Account created! Please Login.";
                } else {
                    $error = "Something went wrong. Try again.";
                }
            }
        } else {
            $error = "All fields are required.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - 7Cuts</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .active-tab { border-bottom: 2px solid #dc2626; color: #dc2626; font-weight: bold; }
        .inactive-tab { color: #9ca3af; }
    </style>
</head>
<body class="bg-gray-50 flex items-center justify-center min-h-screen p-4">

    <div class="bg-white w-full max-w-sm rounded-2xl shadow-lg overflow-hidden">
        
        <div class="flex border-b border-gray-100">
            <button onclick="switchTab('login')" id="tab-login" class="flex-1 py-4 text-center active-tab transition">Login</button>
            <button onclick="switchTab('signup')" id="tab-signup" class="flex-1 py-4 text-center inactive-tab transition">Signup</button>
        </div>

        <div class="p-8">
            
            <?php if($error): ?>
                <div class="bg-red-50 text-red-600 text-sm p-3 rounded-lg mb-4 text-center font-bold border border-red-100"><?= $error ?></div>
            <?php endif; ?>
            <?php if($success): ?>
                <div class="bg-green-50 text-green-600 text-sm p-3 rounded-lg mb-4 text-center font-bold border border-green-100"><?= $success ?></div>
            <?php endif; ?>

            <form id="form-login" method="POST" class="space-y-4">
                <input type="hidden" name="action" value="login">
                <h2 class="text-2xl font-bold text-gray-800 mb-2">Welcome Back</h2>
                
                <div>
                    <input type="email" name="email" placeholder="Email Address" required 
                           class="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-3 outline-none focus:border-red-500 focus:ring-1 focus:ring-red-500 transition">
                </div>
                <div>
                    <input type="password" name="password" placeholder="Password" required 
                           class="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-3 outline-none focus:border-red-500 focus:ring-1 focus:ring-red-500 transition">
                </div>
                
                <button type="submit" class="w-full bg-red-600 text-white font-bold py-3.5 rounded-xl shadow-md hover:bg-red-700 active:scale-95 transition">
                    Login
                </button>
            </form>

            <form id="form-signup" method="POST" class="space-y-4 hidden">
                <input type="hidden" name="action" value="signup">
                <h2 class="text-2xl font-bold text-gray-800 mb-2">Create Account</h2>
                
                <div>
                    <input type="text" name="name" placeholder="Full Name" required 
                           class="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-3 outline-none focus:border-red-500 focus:ring-1 focus:ring-red-500 transition">
                </div>
                <div>
                    <input type="email" name="email" placeholder="Email Address" required 
                           class="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-3 outline-none focus:border-red-500 focus:ring-1 focus:ring-red-500 transition">
                </div>
                <div>
                    <input type="password" name="password" placeholder="Create Password" required 
                           class="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-3 outline-none focus:border-red-500 focus:ring-1 focus:ring-red-500 transition">
                </div>
                
                <button type="submit" class="w-full bg-red-600 text-white font-bold py-3.5 rounded-xl shadow-md hover:bg-red-700 active:scale-95 transition">
                    Sign Up
                </button>
            </form>

        </div>
    </div>

<script>
    function switchTab(tab) {
        const loginForm = document.getElementById('form-login');
        const signupForm = document.getElementById('form-signup');
        const loginTab = document.getElementById('tab-login');
        const signupTab = document.getElementById('tab-signup');

        if (tab === 'login') {
            loginForm.classList.remove('hidden');
            signupForm.classList.add('hidden');
            loginTab.classList.add('active-tab');
            loginTab.classList.remove('inactive-tab');
            signupTab.classList.remove('active-tab');
            signupTab.classList.add('inactive-tab');
        } else {
            loginForm.classList.add('hidden');
            signupForm.classList.remove('hidden');
            signupTab.classList.add('active-tab');
            signupTab.classList.remove('inactive-tab');
            loginTab.classList.remove('active-tab');
            loginTab.classList.add('inactive-tab');
        }
    }
</script>

</body>
</html>
