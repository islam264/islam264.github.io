<?php
require 'common/config.php';

try {
    // 1. Column ka size badha kar TEXT kar rahe hain
    $conn->exec("ALTER TABLE products MODIFY image TEXT");
    echo "<h1 style='color:green'>✅ Database Fixed Successfully!</h1>";
    echo "<p>Ab products table lambi image lists store kar sakti hai.</p>";
    echo "<a href='admin/index.php'>Go Back to Admin</a>";
} catch(PDOException $e) {
    echo "<h1>Error: " . $e->getMessage() . "</h1>";
}
?>
