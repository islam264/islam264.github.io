<?php
$host = "127.0.0.1";
$user = "root";
$pass = "root";

try {
    $pdo = new PDO("mysql:host=$host", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Create DB
    $pdo->exec("CREATE DATABASE IF NOT EXISTS 7cuts_db");
    $pdo->exec("USE 7cuts_db");

    // Tables
    $sql = "
    CREATE TABLE IF NOT EXISTS users (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(100),
        email VARCHAR(100) UNIQUE,
        phone VARCHAR(20),
        password VARCHAR(255),
        address TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS admin (
        id INT AUTO_INCREMENT PRIMARY KEY,
        username VARCHAR(100) UNIQUE,
        password VARCHAR(255)
    );

    CREATE TABLE IF NOT EXISTS categories (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(100),
        image VARCHAR(255)
    );

    CREATE TABLE IF NOT EXISTS products (
        id INT AUTO_INCREMENT PRIMARY KEY,
        category_id INT,
        name VARCHAR(200),
        description TEXT,
        price DECIMAL(10,2),
        stock INT DEFAULT 0,
        image VARCHAR(255),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS orders (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT,
        total_amount DECIMAL(10,2),
        address TEXT,
        payment_method VARCHAR(50) DEFAULT 'COD',
        status ENUM('Placed','Dispatched','Delivered') DEFAULT 'Placed',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS order_items (
        id INT AUTO_INCREMENT PRIMARY KEY,
        order_id INT,
        product_id INT,
        quantity INT,
        price DECIMAL(10,2)
    );
    ";
    
    $pdo->exec($sql);

    // Create Default Admin (User: admin, Pass: admin123)
    $stmt = $pdo->prepare("SELECT * FROM admin WHERE username='admin'");
    $stmt->execute();
    if($stmt->rowCount() == 0) {
        $hash = password_hash("admin123", PASSWORD_DEFAULT);
        $pdo->exec("INSERT INTO admin (username, password) VALUES ('admin', '$hash')");
    }

    // Create uploads folder
    if (!file_exists('uploads')) {
        mkdir('uploads', 0777, true);
    }

    echo "<h1 style='color:green; text-align:center;'>Installation Successful!</h1>";
    echo "<p style='text-align:center;'>Default Admin: <b>admin</b> / <b>admin123</b></p>";
    echo "<script>setTimeout(() => { window.location.href='login.php'; }, 3000);</script>";

} catch(PDOException $e) {
    die("Setup failed: " . $e->getMessage());
}
?>
