<?php
require 'common/config.php';
include 'common/header.php';

// 1. GET PRODUCT DETAILS
$id = isset($_GET['id']) ? intval($_GET['id']) : 0;
$stmt = $conn->prepare("SELECT * FROM products WHERE id = ?");
$stmt->execute([$id]);
$p = $stmt->fetch();

if (!$p) {
    echo "<div class='p-10 text-center'>Product not found. <a href='index.php' class='text-red-600 font-bold'>Home</a></div>";
    exit;
}

// 2. FETCH SIMILAR PRODUCTS
// Logic: Same Category (cat_id) par Current Product (id) ko chhodkar
$stmtSim = $conn->prepare("SELECT * FROM products WHERE cat_id = ? AND id != ? ORDER BY RAND() LIMIT 4");
$stmtSim->execute([$p['cat_id'], $id]);
$similarProducts = $stmtSim->fetchAll();

// Discount & Sizes
$discount = 0;
if($p['mrp'] > $p['price']) {
    $discount = round((($p['mrp'] - $p['price']) / $p['mrp']) * 100);
}
$sizeList = !empty($p['sizes']) ? explode(',', $p['sizes']) : ['Standard'];

// Image Handling
$rawImage = $p['image'];
$imageList = [];
if (strpos($rawImage, ',') !== false) {
    $imageList = explode(',', $rawImage);
} else {
    $imageList[] = $rawImage;
}
function fixPath($path) {
    $path = trim($path);
    if (strpos($path, 'uploads/') === 0) $path = substr($path, 8);
    return "uploads/" . $path;
}
$imageList = array_map('fixPath', $imageList);
$imageList = array_filter($imageList);
?>

<style>
    .size-btn.selected { border-color: #dc2626; background-color: #fef2f2; color: #dc2626; font-weight: bold; }
    .thumb-btn.active-thumb { border-color: #dc2626; border-width: 2px; }
    .no-scrollbar::-webkit-scrollbar { display: none; }
    .no-scrollbar { -ms-overflow-style: none; scrollbar-width: none; }
    #imageModal { transition: opacity 0.3s ease-in-out; }
    #modalImg { transition: transform 0.3s ease-in-out; }
</style>

<div class="bg-white min-h-screen pb-32 overflow-x-hidden">

    <div class="w-full bg-gray-50 pt-4 pb-6 rounded-b-3xl relative">
        <div class="px-4 flex justify-between mb-2 absolute top-4 left-0 w-full z-10">
            <a href="index.php" class="ml-4 w-9 h-9 bg-white rounded-full shadow-sm flex items-center justify-center text-gray-600 hover:text-red-600"><i class="fas fa-arrow-left"></i></a>
            <a href="cart.php" class="mr-4 w-9 h-9 bg-white rounded-full shadow-sm flex items-center justify-center text-gray-600 hover:text-red-600 relative">
                <i class="fas fa-shopping-cart"></i>
                <?php if(isset($_SESSION['cart']) && count($_SESSION['cart']) > 0): ?>
                    <span class="absolute -top-1 -right-1 bg-red-600 text-white text-[10px] w-4 h-4 rounded-full flex items-center justify-center border border-white"><?= array_sum($_SESSION['cart']) ?></span>
                <?php endif; ?>
            </a>
        </div>

        <div class="h-80 flex items-center justify-center mb-4 px-4 pt-10">
            <img id="mainImage" onclick="openModal()" src="<?= getImg($imageList[0]) ?>" class="max-h-full max-w-full object-contain mix-blend-multiply cursor-pointer transition-transform active:scale-95">
            <div class="absolute bottom-24 right-6 bg-white/80 p-2 rounded-full pointer-events-none text-gray-500 text-xs shadow-sm">
                <i class="fas fa-expand-alt"></i> Tap to Zoom
            </div>
        </div>

        <?php if(count($imageList) > 1): ?>
        <div class="px-4 w-full">
            <div class="flex gap-3 overflow-x-auto no-scrollbar pb-2 border border-gray-200 p-2 rounded-xl bg-white shadow-sm w-full max-w-full">
                <?php foreach($imageList as $index => $img): ?>
                <button onclick="changeImage('<?= getImg($img) ?>', this)" 
                        class="thumb-btn w-14 h-14 rounded-lg border border-gray-100 bg-white p-1 flex-shrink-0 overflow-hidden <?= $index===0 ? 'active-thumb' : '' ?>">
                    <img src="<?= getImg($img) ?>" class="w-full h-full object-contain">
                </button>
                <?php endforeach; ?>
            </div>
        </div>
        <?php endif; ?>
    </div>

    <div class="px-5 py-6">
        <h1 class="text-2xl font-bold text-gray-900 leading-tight mb-1"><?= htmlspecialchars($p['name']) ?></h1>
        <p class="text-xs text-gray-400 mb-4">ID: <?= $p['id'] ?></p>

        <div class="flex items-center gap-3 mb-6">
            <span class="text-3xl font-black text-gray-900">₹<?= number_format($p['price']) ?></span>
            <?php if($p['mrp'] > $p['price']): ?>
                <span class="text-gray-400 line-through text-sm">₹<?= $p['mrp'] ?></span>
                <span class="text-green-600 text-xs font-bold bg-green-50 px-2 py-1 rounded"><?= $discount ?>% OFF</span>
            <?php endif; ?>
        </div>

        <div class="mb-6">
            <h3 class="text-sm font-bold text-gray-800 mb-3 uppercase tracking-wide">Select Option</h3>
            <div class="flex flex-wrap gap-3">
                <?php foreach($sizeList as $index => $size): ?>
                <button onclick="selectSize(this)" class="size-btn px-5 py-2.5 rounded-lg border border-gray-200 text-sm font-medium text-gray-600 <?= $index === 0 ? 'selected' : '' ?>">
                    <?= trim($size) ?>
                </button>
                <?php endforeach; ?>
            </div>
        </div>

        <div class="border-t border-gray-100 pt-6 mb-8">
            <h3 class="text-sm font-bold text-gray-800 mb-3">Description</h3>
            <p class="text-sm text-gray-600 leading-7">
                <?= nl2br(htmlspecialchars($p['description'])) ?>
            </p>
        </div>

        <?php if(count($similarProducts) > 0): ?>
        <div class="border-t border-gray-100 pt-6">
            <h3 class="text-lg font-bold text-gray-900 mb-4">You May Also Like</h3>
            <div class="grid grid-cols-2 gap-3">
                <?php foreach($similarProducts as $sim): 
                    // Process Image for Similar Product
                    $sImg = $sim['image'];
                    if(strpos($sImg, ',') !== false) {
                        $sArr = explode(',', $sImg);
                        $sImg = $sArr[0];
                    }
                    $sImg = getImg(trim($sImg));
                ?>
                <div class="bg-white rounded-xl border border-gray-100 shadow-sm overflow-hidden flex flex-col">
                    <a href="product_detail.php?id=<?= $sim['id'] ?>" class="h-32 p-4 flex items-center justify-center bg-gray-50">
                        <img src="<?= $sImg ?>" class="max-h-full max-w-full object-contain mix-blend-multiply">
                    </a>
                    <div class="p-3 flex-1 flex flex-col">
                        <h4 class="text-xs font-bold text-gray-800 line-clamp-1 mb-1"><?= htmlspecialchars($sim['name']) ?></h4>
                        <div class="mt-auto flex justify-between items-center">
                            <span class="text-sm font-black text-red-600">₹<?= number_format($sim['price']) ?></span>
                            <button onclick="addToCartGeneric(<?= $sim['id'] ?>, this)" class="w-6 h-6 rounded bg-red-50 text-red-600 flex items-center justify-center hover:bg-red-600 hover:text-white transition">
                                <i class="fas fa-plus text-[10px]"></i>
                            </button>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php endif; ?>

    </div>
</div>

<div class="fixed bottom-0 left-0 w-full bg-white p-4 border-t border-gray-100 shadow-[0_-5px_15px_rgba(0,0,0,0.05)] z-50">
    <button id="addBtn" onclick="addToCartMain(<?= $p['id'] ?>)" class="w-full bg-red-600 text-white font-bold text-lg py-3.5 rounded-xl shadow-lg hover:bg-red-700 transition active:scale-95 uppercase tracking-wide">
        ADD TO CART
    </button>
</div>

<div id="imageModal" class="fixed inset-0 bg-black/95 z-[100] hidden flex items-center justify-center opacity-0">
    <button onclick="closeModal()" class="absolute top-5 right-5 w-10 h-10 bg-white/20 rounded-full flex items-center justify-center text-white hover:bg-white/30 backdrop-blur-md transition z-[101]">
        <i class="fas fa-times text-xl"></i>
    </button>
    <img id="modalImg" src="" class="max-w-screen max-h-screen object-contain p-2 transform scale-95">
</div>

<script>
// --- MODAL & IMAGE LOGIC ---
function openModal() {
    const mainSrc = document.getElementById('mainImage').src;
    const modal = document.getElementById('imageModal');
    const modalImg = document.getElementById('modalImg');
    modalImg.src = mainSrc;
    modal.classList.remove('hidden');
    setTimeout(() => { modal.classList.remove('opacity-0'); modalImg.classList.remove('scale-95'); modalImg.classList.add('scale-100'); }, 10);
}
function closeModal() {
    const modal = document.getElementById('imageModal');
    const modalImg = document.getElementById('modalImg');
    modal.classList.add('opacity-0'); modalImg.classList.remove('scale-100'); modalImg.classList.add('scale-95');
    setTimeout(() => { modal.classList.add('hidden'); }, 300);
}
function changeImage(src, btn) {
    const mainImg = document.getElementById('mainImage');
    mainImg.style.opacity = '0.5';
    setTimeout(() => { mainImg.src = src; mainImg.style.opacity = '1'; }, 150);
    document.querySelectorAll('.thumb-btn').forEach(b => b.classList.remove('active-thumb'));
    btn.classList.add('active-thumb');
}
function selectSize(btn) {
    document.querySelectorAll('.size-btn').forEach(b => b.classList.remove('selected'));
    btn.classList.add('selected');
}

// --- ADD TO CART (MAIN PRODUCT) ---
async function addToCartMain(pid) {
    const btn = document.getElementById('addBtn');
    const originalText = btn.innerHTML;
    btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> ADDING...';
    btn.disabled = true;
    try {
        const res = await fetch('cart.php', { method: 'POST', headers: {'Content-Type': 'application/x-www-form-urlencoded'}, body: `action=add&pid=${pid}&qty=1` });
        const data = await res.json();
        if(data.success) { btn.innerHTML = 'ADDED <i class="fas fa-check"></i>'; btn.classList.replace('bg-red-600','bg-green-600'); setTimeout(() => location.href = 'cart.php', 500); }
        else { alert("Error"); btn.innerHTML = originalText; btn.disabled = false; }
    } catch(e) { console.error(e); btn.innerHTML = originalText; btn.disabled = false; }
}

// --- ADD TO CART (SIMILAR PRODUCT) ---
async function addToCartGeneric(pid, btn) {
    const originalContent = btn.innerHTML;
    btn.innerHTML = '<i class="fas fa-spinner fa-spin text-[10px]"></i>';
    try {
        const res = await fetch('cart.php', { method: 'POST', headers: {'Content-Type': 'application/x-www-form-urlencoded'}, body: `action=add&pid=${pid}&qty=1` });
        const data = await res.json();
        if(data.success) { 
            btn.innerHTML = '<i class="fas fa-check text-[10px]"></i>';
            btn.classList.replace('bg-red-50', 'bg-green-500');
            btn.classList.replace('text-red-600', 'text-white');
            location.reload(); // Reload to update header cart count
        }
    } catch(e) { 
        console.error(e); 
        btn.innerHTML = originalContent; 
    }
}
</script>
