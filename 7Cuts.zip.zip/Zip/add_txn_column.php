<?php
require 'common/config.php';

try {
    echo "<h2>⚙️ Adding Transaction ID Column...</h2>";
    // payment_method aur txn_id column add kar rahe hain
    $conn->exec("ALTER TABLE orders ADD COLUMN payment_method VARCHAR(50) DEFAULT 'COD'");
    $conn->exec("ALTER TABLE orders ADD COLUMN txn_id VARCHAR(100) DEFAULT NULL");
    
    echo "<h3 style='color:green'>✅ Success! Database Updated.</h3>";
} catch(PDOException $e) {
    echo "<h3>Column already exists or Error: " . $e->getMessage() . "</h3>";
}
?>
