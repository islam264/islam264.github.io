<?php
require 'common/config.php';
try {
    $conn->exec("ALTER TABLE products MODIFY image TEXT");
    echo "✅ Database Updated for Multiple Images!";
} catch(PDOException $e) {
    echo "Already Updated or Error: " . $e->getMessage();
}
?>
