<nav class="md:hidden fixed bottom-0 left-0 w-full bg-white shadow-[0_-2px_10px_rgba(0,0,0,0.05)] z-40 flex justify-around py-3 border-t">
    <a href="index.php" class="flex flex-col items-center text-gray-500 hover:text-red-600 <?php echo basename($_SERVER['PHP_SELF'])=='index.php'?'text-red-600':''; ?>">
        <i class="fas fa-home text-lg"></i>
        <span class="text-[10px] mt-1">Home</span>
    </a>
    <a href="cart.php" class="flex flex-col items-center text-gray-500 hover:text-red-600 <?php echo basename($_SERVER['PHP_SELF'])=='cart.php'?'text-red-600':''; ?>">
        <i class="fas fa-shopping-bag text-lg"></i>
        <span class="text-[10px] mt-1">Cart</span>
    </a>
    <a href="order.php" class="flex flex-col items-center text-gray-500 hover:text-red-600 <?php echo basename($_SERVER['PHP_SELF'])=='order.php'?'text-red-600':''; ?>">
        <i class="fas fa-box text-lg"></i>
        <span class="text-[10px] mt-1">Orders</span>
    </a>
    <a href="profile.php" class="flex flex-col items-center text-gray-500 hover:text-red-600 <?php echo basename($_SERVER['PHP_SELF'])=='profile.php'?'text-red-600':''; ?>">
        <i class="fas fa-user text-lg"></i>
        <span class="text-[10px] mt-1">Profile</span>
    </a>
</nav>

<script>
    // Security Scripts
    document.addEventListener('contextmenu', event => event.preventDefault());
    document.addEventListener('keydown', function(event) {
        if (event.ctrlKey && (event.key === 'u' || event.key === 's' || event.key === 'i' || event.key === '+' || event.key === '-')) {
            event.preventDefault();
        }
    });

    // Loading Helper
    const showLoader = () => document.getElementById('loading').classList.remove('hidden');
    const hideLoader = () => document.getElementById('loading').classList.add('hidden');
</script>
</body>
</html>
