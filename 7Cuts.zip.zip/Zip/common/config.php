<?php
// ⚠️ DHYAN DEIN: Is line se pehle koi space ya khali line nahi honi chahiye.

// 1. DATABASE CONNECTION (Live AquaHost Support)
$connections = [
    // Live Server: AquaHost Credentials
    [
        'host' => 'localhost', 
        'user' => 'bceysmzk', // Aapka AquaHost Username
        'pass' => '[5IHYsO2n5O!Qm', // Aapka AquaHost Password
        'dbname' => 'bceysmzk_7cuts_db' // AquaHost par banaya hua Database Name
    ],
    // Fallback: Local Environment
    ['host' => '127.0.0.1', 'user' => 'root', 'pass' => ''],
    ['host' => 'localhost', 'user' => 'root', 'pass' => '']
];

$dbname = "bceysmzk_7cuts_db"; 
$conn = null;
$connected = false;
$lastError = "";

foreach ($connections as $c) {
    try {
        $dsn = "mysql:host={$c['host']};dbname={$c['dbname']};charset=utf8";
        $conn = new PDO($dsn, $c['user'], $c['pass']);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $connected = true;
        break; 
    } catch (PDOException $e) {
        $lastError = $e->getMessage();
        continue; 
    }
}

if (!$connected) {
    die("<div style='text-align:center;margin-top:50px;font-family:sans-serif;'>
            <h3 style='color:red;'>⚠️ Database Connection Failed!</h3>
            <p>Please ensure your database 'bceysmzk_7cuts_db' is created in AquaHost cPanel.</p>
            <p style='font-size:12px; color:gray;'>Error: $lastError</p>
         </div>");
}

// 2. SESSION START (Hamesha top par)
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// 3. FETCH GLOBAL SETTINGS
$app = [];
try {
    $settingsStmt = $conn->query("SELECT * FROM settings WHERE id = 1");
    $app = $settingsStmt->fetch(PDO::FETCH_ASSOC);
} catch (Exception $e) { $app = []; }

// 4. SMART IMAGE FUNCTIONS (Path Fix for Live Server)
function getImg($path) {
    if (empty($path)) return "assets/no-image.png";
    $path = trim($path);
    if (strpos($path, ',') !== false) {
        $parts = explode(',', $path);
        $path = trim($parts[0]);
    }
    if (strpos($path, 'http') === 0) return $path;
    return (strpos($path, 'uploads/') === 0) ? $path : "uploads/" . $path;
}

function getCatImg($path) {
    if (empty($path)) return "assets/no-category.png";
    $path = trim($path);
    return (strpos($path, 'uploads/') === 0) ? $path : "uploads/" . $path;
}

function getAdminQR() {
    global $app;
    return (!empty($app['qr_code'])) ? $app['qr_code'] : 'assets/my_qr.jpg';
}
?>
