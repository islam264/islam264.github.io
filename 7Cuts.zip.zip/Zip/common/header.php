<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
$searchValue = isset($_GET['search']) ? htmlspecialchars($_GET['search']) : '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>7Cuts - Premium Meat</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        html { scroll-behavior: smooth; }
        .no-scrollbar::-webkit-scrollbar { display: none; }
        .no-scrollbar { -ms-overflow-style: none; scrollbar-width: none; }
        .bg-cream { background-color: #FEF8E6; }
    </style>
</head>
<body class="bg-cream text-gray-900 antialiased">

    <nav class="fixed top-0 left-0 w-full bg-white shadow-sm z-50 h-16 flex items-center border-b border-[#F0E6D2]">
        <div class="container mx-auto px-4 flex items-center justify-between gap-3">
            
            <a href="index.php" class="text-2xl font-black text-red-700 tracking-tighter flex-shrink-0" style="font-family: sans-serif;">
                7Cuts
            </a>

            <form action="index.php" method="GET" class="flex-1 max-w-lg relative">
                <i class="fas fa-search absolute left-3 top-2.5 text-gray-400 text-xs"></i>
                <input type="text" name="search" value="<?= $searchValue ?>" placeholder="Search here..." 
                       class="w-full bg-[#FEF8E6] text-gray-800 pl-8 pr-3 py-2 rounded-full focus:outline-none focus:ring-1 focus:ring-red-500 font-medium text-xs border border-[#F0E6D2]">
            </form>

            <a href="cart.php" class="relative p-2 text-gray-700 hover:text-red-700 transition flex-shrink-0">
                <i class="fas fa-shopping-cart text-lg"></i>
                <?php 
                    $cartCount = isset($_SESSION['cart']) ? array_sum($_SESSION['cart']) : 0;
                    if($cartCount > 0): 
                ?>
                    <span class="absolute top-0 right-0 bg-red-600 text-white text-[9px] font-bold px-1.5 py-0.5 rounded-full border border-white">
                        <?= $cartCount ?>
                    </span>
                <?php endif; ?>
            </a>
        </div>
    </nav>
    
    <div class="h-16"></div>
