<?php
require 'common/config.php';

try {
    echo "<h2>⚙️ Fixing Order Status Column...</h2>";

    // Column ka size badha kar VARCHAR(50) kar rahe hain
    // Taaki "Out for Delivery" aur "Cancelled" jaise words aaram se aa sakein
    $sql = "ALTER TABLE orders MODIFY status VARCHAR(50) DEFAULT 'Pending'";
    
    $conn->exec($sql);
    
    echo "<h3 style='color:green'>✅ Success! Status column size increased.</h3>";
    echo "<p>Ab aap 'Out for Delivery' status update kar sakte hain.</p>";
    
    echo "<br><hr>";
    echo "<a href='admin/order.php' style='background:red; color:white; padding:10px 20px; text-decoration:none; border-radius:5px;'>Go Back to Orders</a>";

} catch(PDOException $e) {
    echo "<h3 style='color:red'>Error: " . $e->getMessage() . "</h3>";
}
?>
