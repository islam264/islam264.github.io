<?php
require 'common/config.php';
include 'common/header.php';

// 1. Get Current Page Slug (Default: privacy)
$slug = isset($_GET['page']) ? $_GET['page'] : 'privacy';

// 2. Fetch Active Policy Content from Database
$stmt = $conn->prepare("SELECT * FROM policies WHERE slug = ?");
$stmt->execute([$slug]);
$current = $stmt->fetch();

// 3. Fetch List of All Policies for Sidebar
try {
    $list = $conn->query("SELECT slug, title FROM policies")->fetchAll();
} catch(Exception $e) {
    $list = [];
}

// Fallback: Agar database mein policy nahi mili
if(!$current) {
    $current = [
        'title' => 'Page Not Found', 
        'content' => 'The requested policy could not be found. Please check back later.'
    ];
}
?>

<div class="bg-gray-50 min-h-screen pb-24">
    <div class="container mx-auto px-4 py-8">
        <h1 class="text-2xl font-bold text-gray-800 mb-6">Legal & Support</h1>
        
        <div class="flex flex-col md:flex-row gap-6">
            
            <div class="w-full md:w-1/4">
                <div class="bg-white rounded-lg shadow-sm overflow-hidden border">
                    <?php if(count($list) > 0): ?>
                        <?php foreach($list as $p): ?>
                        <a href="?page=<?= $p['slug'] ?>" class="block px-4 py-3 border-b hover:bg-gray-50 flex items-center justify-between transition <?= $slug==$p['slug'] ? 'bg-red-50 text-red-600 font-bold' : 'text-gray-600' ?>">
                            <span><?= htmlspecialchars($p['title']) ?></span>
                            <?php if($slug==$p['slug']): ?> <i class="fas fa-chevron-right text-xs"></i> <?php endif; ?>
                        </a>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <p class="p-4 text-sm text-gray-500">No policies found.</p>
                    <?php endif; ?>
                </div>
            </div>

            <div class="w-full md:w-3/4">
                <div class="bg-white rounded-lg shadow-sm p-6 border min-h-[400px]">
                    
                    <h2 class="text-2xl font-bold text-gray-800 mb-4 pb-3 border-b border-gray-100">
                        <?= htmlspecialchars($current['title']) ?>
                    </h2>
                    
                    <div class="text-gray-700 leading-loose text-sm md:text-base space-y-4">
                        <?= nl2br($current['content']) ?> 
                    </div>

                </div>
            </div>

        </div>
    </div>
</div>

<?php include 'common/bottom.php'; ?>
