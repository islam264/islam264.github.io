<?php
require '../common/config.php';
if(!isset($_SESSION['admin_id'])) { header("Location: login.php"); exit; }

// Handle Upload
if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_FILES['banner'])) {
    $targetDir = "../uploads/";
    if(!is_dir($targetDir)) mkdir($targetDir);
    
    $fileName = time() . "_" . basename($_FILES["banner"]["name"]);
    $targetFilePath = $targetDir . $fileName;
    $dbPath = "uploads/" . $fileName;

    if(move_uploaded_file($_FILES["banner"]["tmp_name"], $targetFilePath)) {
        $stmt = $conn->prepare("INSERT INTO banners (image) VALUES (?)");
        $stmt->execute([$dbPath]);
        $success = "Banner Added Successfully!";
    } else {
        $error = "Failed to upload image.";
    }
}

// Handle Delete
if(isset($_GET['delete'])) {
    $id = $_GET['delete'];
    $conn->prepare("DELETE FROM banners WHERE id=?")->execute([$id]);
    header("Location: banners.php");
    exit;
}

// Fetch Banners
$banners = $conn->query("SELECT * FROM banners ORDER BY id DESC")->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Banners - Admin</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="bg-gray-100 flex h-screen">

    <aside class="w-64 bg-gray-900 text-white hidden md:flex flex-col">
        <div class="p-6 text-2xl font-bold border-b border-gray-700">7Cuts Admin</div>
        <nav class="flex-1 p-4 space-y-2">
            <a href="index.php" class="block py-3 px-4 rounded text-gray-300 hover:bg-gray-800">Dashboard</a>
            <a href="banners.php" class="block py-3 px-4 rounded bg-red-600 text-white font-bold">Banners</a>
            <a href="../index.php" target="_blank" class="block py-3 px-4 mt-10 border-t border-gray-700 text-gray-400">Visit Site</a>
        </nav>
    </aside>

    <main class="flex-1 p-6 overflow-y-auto">
        <div class="md:hidden flex justify-between items-center mb-6">
            <h1 class="text-xl font-bold">Banners</h1>
            <a href="index.php" class="bg-gray-800 text-white px-3 py-1 rounded">Menu</a>
        </div>

        <h2 class="text-2xl font-bold mb-6 text-gray-800">Home Screen Sliders</h2>

        <?php if(isset($success)) echo "<div class='bg-green-100 text-green-700 p-3 rounded mb-4'>$success</div>"; ?>

        <div class="bg-white p-6 rounded-lg shadow-sm border mb-8">
            <form method="POST" enctype="multipart/form-data" class="flex gap-4 items-end">
                <div class="flex-1">
                    <label class="block text-sm font-bold text-gray-700 mb-1">Upload New Banner</label>
                    <input type="file" name="banner" class="w-full border p-2 rounded bg-gray-50" required accept="image/*">
                </div>
                <button type="submit" class="bg-red-600 text-white px-6 py-3 rounded font-bold hover:bg-red-700">Add Banner</button>
            </form>
            <p class="text-xs text-gray-400 mt-2">Recommended Size: 800x400 pixels (Landscape)</p>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <?php foreach($banners as $b): ?>
            <div class="bg-white rounded-lg shadow border overflow-hidden relative group">
                <img src="../<?= $b['image'] ?>" class="w-full h-40 object-cover">
                <div class="p-3 flex justify-between items-center bg-gray-50">
                    <span class="text-xs text-gray-500">ID: <?= $b['id'] ?></span>
                    <a href="?delete=<?= $b['id'] ?>" class="text-red-600 hover:text-red-800 font-bold text-sm" onclick="return confirm('Delete this banner?')">
                        <i class="fas fa-trash"></i> Delete
                    </a>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </main>
</body>
</html>
