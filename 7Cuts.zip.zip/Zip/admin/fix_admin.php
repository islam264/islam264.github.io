<?php
// Is file ko apne root folder me rakhein (jahan index.php hai)
require 'common/config.php';

try {
    echo "<h2>Repairing Database...</h2>";

    // 1. Create Admin Table (Agar nahi hai to ban jayegi)
    $sql = "CREATE TABLE IF NOT EXISTS admin (
        id INT AUTO_INCREMENT PRIMARY KEY,
        username VARCHAR(100) UNIQUE,
        password VARCHAR(255)
    )";
    $conn->exec($sql);
    echo "✅ Admin Table created successfully.<br>";

    // 2. Check if admin user exists
    $stmt = $conn->prepare("SELECT * FROM admin WHERE username='admin'");
    $stmt->execute();
    
    if($stmt->rowCount() == 0) {
        // 3. Insert Default Admin (Agar user nahi hai to ban jayega)
        $pass = password_hash("admin123", PASSWORD_DEFAULT);
        $stmt = $conn->prepare("INSERT INTO admin (username, password) VALUES ('admin', ?)");
        $stmt->execute([$pass]);
        echo "✅ Admin User created! (Username: <b>admin</b> / Password: <b>admin123</b>)<br>";
    } else {
        echo "ℹ️ Admin user already exists. Password is likely <b>admin123</b>.<br>";
    }

    echo "<br><hr><a href='admin/login.php' style='background:red; color:white; padding:10px 20px; text-decoration:none; border-radius:5px;'>Go to Admin Login Now</a>";

} catch(PDOException $e) {
    echo "<h3 style='color:red'>Error: " . $e->getMessage() . "</h3>";
    echo "Please check your database connection in common/config.php";
}
?>
