<?php
require '../common/config.php';
// Check Admin Login
if(!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit;
}

// Handle Form Submit (Add/Delete)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // DELETE Category
    if (isset($_POST['delete_id'])) {
        $stmt = $conn->prepare("DELETE FROM categories WHERE id=?");
        $stmt->execute([$_POST['delete_id']]);
        header("Location: category.php");
        exit;
    }

    // ADD Category
    $name = $_POST['name'];
    $imgName = "";

    // Image Upload Logic
    if (!empty($_FILES['image']['name'])) {
        $targetDir = "../uploads/";
        $imgName = time() . "_" . basename($_FILES['image']['name']);
        move_uploaded_file($_FILES['image']['tmp_name'], $targetDir . $imgName);
    }

    try {
        $stmt = $conn->prepare("INSERT INTO categories (name, image) VALUES (?, ?)");
        $stmt->execute([$name, $imgName]);
        $success = "Category Added Successfully!";
    } catch (Exception $e) {
        $error = "Error: " . $e->getMessage();
    }
}

// Fetch Categories
$cats = $conn->query("SELECT * FROM categories ORDER BY id DESC")->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Categories - Admin</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="bg-gray-100">

<div class="flex min-h-screen">
    <aside class="w-64 bg-gray-900 text-white flex flex-col hidden md:flex">
        <div class="p-6 text-2xl font-bold border-b border-gray-700">7Cuts Admin</div>
        <nav class="flex-1 p-4 space-y-2">
            <a href="index.php" class="block py-3 px-4 rounded hover:bg-gray-800 text-gray-300">Dashboard</a>
            <a href="category.php" class="block py-3 px-4 rounded bg-red-600 text-white font-bold">Categories</a>
            <a href="product.php" class="block py-3 px-4 rounded hover:bg-gray-800 text-gray-300">Products</a>
            <a href="order.php" class="block py-3 px-4 rounded hover:bg-gray-800 text-gray-300">Orders</a>
        </nav>
        <a href="login.php?logout=true" class="p-4 bg-red-800 text-center hover:bg-red-700">Logout</a>
    </aside>

    <main class="flex-1 p-6">
        <div class="md:hidden flex justify-between items-center mb-6">
            <h1 class="text-xl font-bold">Categories</h1>
            <a href="index.php" class="bg-gray-800 text-white px-3 py-1 rounded">Menu</a>
        </div>

        <h2 class="text-2xl font-bold mb-6 text-gray-800">Categories</h2>

        <?php if(isset($success)) echo "<div class='bg-green-100 text-green-700 p-3 rounded mb-4'>$success</div>"; ?>
        <?php if(isset($error)) echo "<div class='bg-red-100 text-red-700 p-3 rounded mb-4'>$error</div>"; ?>

        <div class="bg-white p-6 rounded-lg shadow-sm border mb-8">
            <h3 class="font-bold text-lg mb-4 border-b pb-2">Add New Category</h3>
            <form method="POST" enctype="multipart/form-data" class="flex flex-col md:flex-row gap-4 items-end">
                <div class="flex-1 w-full">
                    <label class="block text-sm font-bold text-gray-700 mb-1">Category Name</label>
                    <input type="text" name="name" placeholder="e.g. Chicken" class="w-full border p-2 rounded" required>
                </div>
                <div class="flex-1 w-full">
                    <label class="block text-sm font-bold text-gray-700 mb-1">Image</label>
                    <input type="file" name="image" class="w-full border p-2 rounded bg-gray-50" required>
                </div>
                <button type="submit" class="bg-green-600 text-white px-6 py-2.5 rounded font-bold hover:bg-green-700 w-full md:w-auto">
                    Add Category
                </button>
            </form>
        </div>

        <div class="bg-white rounded-lg shadow-sm border overflow-hidden">
            <table class="w-full text-left border-collapse">
                <thead class="bg-gray-50 border-b text-gray-500 text-sm uppercase">
                    <tr>
                        <th class="p-4">Image</th>
                        <th class="p-4">Name</th>
                        <th class="p-4 text-right">Action</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-100">
                    <?php foreach($cats as $c): ?>
                    <tr class="hover:bg-gray-50">
                        <td class="p-4">
                            <img src="../uploads/<?= htmlspecialchars($c['image']) ?>" class="w-12 h-12 object-cover rounded-full border">
                        </td>
                        <td class="p-4 font-bold text-gray-700"><?= htmlspecialchars($c['name']) ?></td>
                        <td class="p-4 text-right">
                            <form method="POST" onsubmit="return confirm('Delete this category?');" class="inline">
                                <input type="hidden" name="delete_id" value="<?= $c['id'] ?>">
                                <button type="submit" class="text-red-500 hover:text-red-700 bg-red-50 px-3 py-1 rounded text-sm font-bold">
                                    Delete
                                </button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    
                    <?php if(count($cats) == 0): ?>
                        <tr><td colspan="3" class="p-6 text-center text-gray-400">No categories found. Add one above!</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </main>
</div>

</body>
</html>
