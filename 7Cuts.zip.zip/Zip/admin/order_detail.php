<?php
require '../common/config.php';

// Login Check
if(!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit;
}

// 1. GET ORDER ID
if(!isset($_GET['id'])) {
    header("Location: order.php");
    exit;
}
$order_id = $_GET['id'];

// 2. HANDLE STATUS UPDATE
if(isset($_POST['update_status'])) {
    $status = $_POST['status'];
    $stmt = $conn->prepare("UPDATE orders SET status=? WHERE id=?");
    $stmt->execute([$status, $order_id]);
    // Refresh to show new status
    header("Location: order_detail.php?id=$order_id");
    exit;
}

// 3. FETCH ORDER DETAILS
$stmt = $conn->prepare("SELECT * FROM orders WHERE id=?");
$stmt->execute([$order_id]);
$order = $stmt->fetch();

if(!$order) {
    echo "Order not found.";
    exit;
}

// 4. FETCH ORDER ITEMS (Agar order_items table hai to)
$items = [];
try {
    // Try connecting to order_items table
    $stmt = $conn->prepare("SELECT order_items.*, products.name, products.image, products.price as p_price FROM order_items JOIN products ON order_items.product_id = products.id WHERE order_id=?");
    $stmt->execute([$order_id]);
    $items = $stmt->fetchAll();
} catch(Exception $e) {
    // Agar table nahi hai to items empty rahenge
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order #<?= $order['id'] ?> - Admin</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="bg-gray-50 font-sans min-h-screen">

    <header class="bg-white shadow-sm sticky top-0 z-10">
        <div class="max-w-3xl mx-auto px-4 h-16 flex items-center justify-between">
            <div class="flex items-center gap-3">
                <a href="order.php" class="w-9 h-9 bg-gray-100 rounded-full flex items-center justify-center text-gray-600 hover:bg-gray-200 transition">
                    <i class="fas fa-arrow-left"></i>
                </a>
                <div>
                    <h1 class="font-bold text-gray-800 text-lg">Order #<?= $order['id'] ?></h1>
                    <p class="text-xs text-gray-400"><?= $order['created_at'] ?? date('Y-m-d') ?></p>
                </div>
            </div>
            
            <span class="px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wide
                <?= $order['status']=='Pending'?'bg-yellow-100 text-yellow-700':'' ?>
                <?= $order['status']=='Placed'?'bg-blue-100 text-blue-700':'' ?>
                <?= $order['status']=='Completed'?'bg-green-100 text-green-700':'' ?>
                <?= $order['status']=='Cancelled'?'bg-red-100 text-red-700':'' ?>
            ">
                <?= $order['status'] ?>
            </span>
        </div>
    </header>

    <main class="max-w-3xl mx-auto p-4 pb-20 space-y-4">

        <div class="bg-white p-5 rounded-2xl shadow-sm border border-gray-100">
            <h3 class="text-xs font-bold text-gray-400 uppercase mb-4 tracking-wider">Customer Details</h3>
            
            <div class="flex items-start gap-4 mb-4">
                <div class="w-10 h-10 rounded-full bg-blue-50 text-blue-600 flex items-center justify-center text-lg">
                    <i class="fas fa-user"></i>
                </div>
                <div>
                    <p class="font-bold text-gray-800"><?= htmlspecialchars($order['name']) ?></p>
                    <p class="text-sm text-gray-500"><i class="fas fa-phone text-xs mr-1"></i> <?= $order['phone'] ?></p>
                </div>
            </div>

            <div class="bg-gray-50 p-4 rounded-xl border border-gray-100">
                <p class="text-xs font-bold text-gray-400 mb-1">DELIVERY ADDRESS</p>
                <p class="text-sm text-gray-700 leading-relaxed">
                    <?= nl2br(htmlspecialchars($order['address'])) ?>
                </p>
            </div>
        </div>

        <div class="bg-white p-5 rounded-2xl shadow-sm border border-gray-100">
            <h3 class="text-xs font-bold text-gray-400 uppercase mb-4 tracking-wider">Ordered Items</h3>
            
            <?php if(count($items) > 0): ?>
                <div class="divide-y divide-gray-50">
                    <?php foreach($items as $item): 
                         // Handle image path
                         $imgSrc = "../" . trim($item['image']);
                         if(strpos($item['image'], 'uploads/') !== 0) $imgSrc = "../uploads/" . trim($item['image']);
                    ?>
                    <div class="py-3 flex items-center gap-4">
                        <img src="<?= $imgSrc ?>" class="w-12 h-12 rounded-lg bg-gray-100 object-cover border">
                        <div class="flex-1">
                            <p class="font-bold text-sm text-gray-800 line-clamp-1"><?= $item['name'] ?></p>
                            <p class="text-xs text-gray-400">Qty: <?= $item['quantity'] ?> × ₹<?= $item['price'] ?></p>
                        </div>
                        <p class="font-bold text-sm text-gray-800">₹<?= $item['quantity'] * $item['price'] ?></p>
                    </div>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <p class="text-sm text-gray-400 italic text-center py-4">
                    Items list not available.<br>
                    <span class="text-xs">(Check if 'order_items' table exists and is populated)</span>
                </p>
            <?php endif; ?>

            <div class="mt-4 pt-4 border-t border-gray-100">
                <div class="flex justify-between items-center text-lg font-black text-gray-800">
                    <span>Total Amount</span>
                    <span>₹<?= number_format($order['total_amount']) ?></span>
                </div>
            </div>
        </div>

        <div class="bg-white p-5 rounded-2xl shadow-sm border border-gray-100">
            <h3 class="text-xs font-bold text-gray-400 uppercase mb-3 tracking-wider">Update Order Status</h3>
            
            <form method="POST" class="flex gap-3">
                <div class="flex-1 relative">
                    <select name="status" class="w-full appearance-none bg-gray-50 border border-gray-200 text-gray-700 py-3 px-4 pr-8 rounded-xl focus:outline-none focus:ring-2 focus:ring-red-500 font-bold">
                        <option value="Pending" <?= $order['status']=='Pending'?'selected':'' ?>>Pending</option>
                        <option value="Placed" <?= $order['status']=='Placed'?'selected':'' ?>>Placed</option>
                        <option value="Shipped" <?= $order['status']=='Shipped'?'selected':'' ?>>Shipped</option>
                        <option value="Out for Delivery" <?= $order['status']=='Out for Delivery'?'selected':'' ?>>Out for Delivery</option>
                        <option value="Completed" <?= $order['status']=='Completed'?'selected':'' ?>>Completed</option>
                        <option value="Cancelled" <?= $order['status']=='Cancelled'?'selected':'' ?>>Cancelled</option>
                    </select>
                    <div class="pointer-events-none absolute inset-y-0 right-0 flex items-center px-3 text-gray-500">
                        <i class="fas fa-chevron-down text-xs"></i>
                    </div>
                </div>
                <button type="submit" name="update_status" class="bg-red-600 text-white px-6 py-3 rounded-xl font-bold hover:bg-red-700 transition shadow-lg shadow-red-200">
                    Update
                </button>
            </form>
        </div>

    </main>

</body>
</html>
