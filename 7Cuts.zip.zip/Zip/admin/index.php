<?php
require '../common/config.php';

if(!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit;
}

try {
    $userCount = $conn->query("SELECT COUNT(DISTINCT phone) FROM orders")->fetchColumn() ?: 0;
    $revenue = $conn->query("SELECT SUM(total_amount) FROM orders")->fetchColumn() ?: 0;
    $orderCount = $conn->query("SELECT COUNT(*) FROM orders")->fetchColumn() ?: 0;
    $productCount = $conn->query("SELECT COUNT(*) FROM products")->fetchColumn() ?: 0;
    $recentOrders = $conn->query("SELECT * FROM orders ORDER BY id DESC LIMIT 5")->fetchAll();
    $qrData = $conn->query("SELECT qr_code FROM settings WHERE id = 1")->fetch();
} catch(Exception $e) {
    $userCount = 0; $revenue = 0; $orderCount = 0; $productCount = 0; $recentOrders = [];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - 7Cuts</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="bg-gray-100 flex h-screen overflow-hidden">

    <aside class="w-64 bg-gray-900 text-white hidden md:flex flex-col flex-shrink-0">
        <div class="p-6 text-2xl font-bold border-b border-gray-700">7Cuts Admin</div>
        <nav class="flex-1 p-4 space-y-2">
            <a href="index.php" class="block py-3 px-4 rounded bg-red-600 text-white font-bold">Dashboard</a>
            <a href="order.php" class="block py-3 px-4 rounded text-gray-300 hover:bg-gray-800 transition">Orders</a>
            <a href="product.php" class="block py-3 px-4 rounded text-gray-300 hover:bg-gray-800 transition">Products</a>
            <a href="categories.php" class="block py-3 px-4 rounded text-gray-300 hover:bg-gray-800 transition">Categories</a>
            <a href="settings.php" class="block py-3 px-4 rounded text-gray-300 hover:bg-gray-800 transition">Settings</a>
            <a href="../index.php" target="_blank" class="block py-3 px-4 mt-10 border-t border-gray-700 text-gray-400">Visit Site</a>
        </nav>
    </aside>

    <main class="flex-1 p-6 overflow-y-auto">
        
        <div class="md:hidden flex justify-between items-center mb-6">
            <h1 class="text-xl font-bold italic text-gray-800">7Cuts Admin</h1>
            <a href="settings.php" class="bg-gray-800 text-white px-3 py-1 rounded text-sm">Settings</a>
        </div>

        <h2 class="text-2xl font-bold mb-6 text-gray-800">Overview</h2>

        <div class="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
            <div class="bg-white p-5 rounded-lg shadow-sm border border-gray-200">
                <p class="text-xs font-bold text-gray-400 uppercase mb-1">Total Revenue</p>
                <h3 class="text-xl font-black text-gray-800">₹<?= number_format($revenue) ?></h3>
            </div>
            <div class="bg-white p-5 rounded-lg shadow-sm border border-gray-200">
                <p class="text-xs font-bold text-gray-400 uppercase mb-1">Total Orders</p>
                <h3 class="text-xl font-black text-gray-800"><?= number_format($orderCount) ?></h3>
            </div>
            <div class="bg-white p-5 rounded-lg shadow-sm border border-gray-200">
                <p class="text-xs font-bold text-gray-400 uppercase mb-1">Customers</p>
                <h3 class="text-xl font-black text-gray-800"><?= number_format($userCount) ?></h3>
            </div>
            <div class="bg-white p-5 rounded-lg shadow-sm border border-gray-200">
                <p class="text-xs font-bold text-gray-400 uppercase mb-1">Products</p>
                <h3 class="text-xl font-black text-gray-800"><?= number_format($productCount) ?></h3>
            </div>
        </div>

        <div class="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
            <div class="lg:col-span-2 bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
                <div class="p-4 border-b flex justify-between items-center">
                    <h3 class="font-bold text-gray-800 text-sm">Recent Orders</h3>
                    <a href="order.php" class="text-xs font-bold text-red-600">View All</a>
                </div>
                <div class="overflow-x-auto text-sm">
                    <table class="w-full text-left">
                        <thead class="bg-gray-50 text-gray-500 uppercase text-[10px] font-bold">
                            <tr>
                                <th class="p-4">Customer</th>
                                <th class="p-4">Amount</th>
                                <th class="p-4">Status</th>
                                <th class="p-4 text-right">Action</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-gray-100">
                            <?php foreach($recentOrders as $o): ?>
                            <tr>
                                <td class="p-4 font-bold text-gray-700"><?= htmlspecialchars($o['name']) ?></td>
                                <td class="p-4 font-bold text-gray-800">₹<?= number_format($o['total_amount']) ?></td>
                                <td class="p-4"><span class="bg-gray-100 px-2 py-0.5 rounded text-[10px] font-bold uppercase"><?= $o['status'] ?></span></td>
                                <td class="p-4 text-right"><a href="order_detail.php?id=<?= $o['id'] ?>" class="text-blue-600 font-bold">View</a></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <div class="bg-white p-5 rounded-lg shadow-sm border border-gray-200 text-center">
                <h3 class="font-bold text-gray-800 text-sm mb-4">Current Payment QR</h3>
                <div class="bg-gray-50 p-3 rounded border border-dashed mb-4">
                    <img src="../<?= $qrData['qr_code'] ?? 'assets/my_qr.jpg' ?>" class="w-32 h-32 mx-auto rounded shadow-sm">
                </div>
                <a href="settings.php" class="inline-block w-full bg-[#1e293b] text-white text-xs py-2.5 rounded font-bold">Update QR Code</a>
            </div>
        </div>

        <h3 class="font-bold text-gray-800 mb-4 text-sm uppercase">Quick Actions</h3>
        <div class="grid grid-cols-2 md:grid-cols-5 gap-4">
            <a href="product.php" class="bg-white p-6 rounded-lg shadow-sm border border-gray-200 flex flex-col items-center gap-2 hover:bg-gray-50 transition">
                <i class="fas fa-plus text-red-600 text-xl"></i>
                <span class="font-bold text-xs text-gray-700">Add Product</span>
            </a>
            <a href="categories.php" class="bg-white p-6 rounded-lg shadow-sm border border-gray-200 flex flex-col items-center gap-2 hover:bg-gray-50 transition text-center">
                <i class="fas fa-tags text-blue-500 text-xl"></i>
                <span class="font-bold text-xs text-gray-700">Categories</span>
            </a>
            <a href="order.php" class="bg-white p-6 rounded-lg shadow-sm border border-gray-200 flex flex-col items-center gap-2 hover:bg-gray-50 transition">
                <i class="fas fa-shopping-cart text-green-600 text-xl"></i>
                <span class="font-bold text-xs text-gray-700">Orders</span>
            </a>
            <a href="settings.php" class="bg-white p-6 rounded-lg shadow-sm border border-gray-200 flex flex-col items-center gap-2 hover:bg-gray-50 transition">
                <i class="fas fa-share-alt text-purple-600 text-xl"></i>
                <span class="font-bold text-xs text-gray-700">Social Links</span>
            </a>
            <a href="settings.php" class="bg-white p-6 rounded-lg shadow-sm border border-gray-200 flex flex-col items-center gap-2 hover:bg-gray-50 transition">
                <i class="fas fa-cog text-gray-600 text-xl"></i>
                <span class="font-bold text-xs text-gray-700">Settings</span>
            </a>
        </div>

    </main>
</body>
</html>
