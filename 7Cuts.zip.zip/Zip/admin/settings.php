<?php
ob_start(); 
require '../common/config.php';

// Login Check
if(!isset($_SESSION['admin_id'])) { 
    header("Location: login.php"); 
    exit; 
}

$success = "";
$error = "";

// --- AUTO-FIX DATABASE TABLES ---
try {
    // Settings table update
    $conn->exec("ALTER TABLE settings ADD COLUMN IF NOT EXISTS qr_code VARCHAR(255) DEFAULT 'assets/my_qr.jpg'");
    $conn->exec("ALTER TABLE settings ADD COLUMN IF NOT EXISTS cod_status INT DEFAULT 1");
    $conn->exec("ALTER TABLE settings ADD COLUMN IF NOT EXISTS whatsapp VARCHAR(20)");
    $conn->exec("ALTER TABLE settings ADD COLUMN IF NOT EXISTS instagram VARCHAR(255)");
    $conn->exec("ALTER TABLE settings ADD COLUMN IF NOT EXISTS facebook VARCHAR(255)");
    $conn->exec("ALTER TABLE settings ADD COLUMN IF NOT EXISTS youtube VARCHAR(255)");

    // Naya Banners Table
    $conn->exec("CREATE TABLE IF NOT EXISTS banners (
        id INT AUTO_INCREMENT PRIMARY KEY,
        image VARCHAR(255) NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )");
} catch(Exception $e) { }

// --- HANDLE BANNER DELETE ---
if(isset($_GET['del_banner'])) {
    $bid = intval($_GET['del_banner']);
    $banner = $conn->query("SELECT image FROM banners WHERE id=$bid")->fetch();
    if($banner) {
        if(file_exists("../".$banner['image'])) { unlink("../".$banner['image']); }
        $conn->query("DELETE FROM banners WHERE id=$bid");
        header("Location: settings.php?success=Banner Deleted");
        exit;
    }
}

// --- HANDLE FORM SUBMISSION ---
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    // 1. General Settings Update
    if(isset($_POST['whatsapp'])) {
        $wa = $_POST['whatsapp'];
        $ig = $_POST['instagram'];
        $fb = $_POST['facebook'];
        $yt = $_POST['youtube'];
        $cod_status = isset($_POST['cod_status']) ? 1 : 0;
        
        $stmt = $conn->prepare("UPDATE settings SET whatsapp=?, instagram=?, facebook=?, youtube=?, cod_status=? WHERE id=1");
        $stmt->execute([$wa, $ig, $fb, $yt, $cod_status]);
        $success = "Settings Updated!";
    }

    // 2. Banner Upload Logic
    if(!empty($_FILES['banner_img']['name'])) {
        $img_name = "uploads/banner_" . time() . "_" . $_FILES['banner_img']['name'];
        if(move_uploaded_file($_FILES['banner_img']['tmp_name'], "../" . $img_name)) {
            $stmt = $conn->prepare("INSERT INTO banners (image) VALUES (?)");
            $stmt->execute([$img_name]);
            $success = "Banner Added!";
        }
    }

    // 3. QR Code Logic
    if(!empty($_FILES['qr_code_img']['name'])) {
        $file_name = "assets/qr_" . time() . ".jpg";
        if(move_uploaded_file($_FILES["qr_code_img"]["tmp_name"], "../" . $file_name)) {
            $conn->prepare("UPDATE settings SET qr_code=? WHERE id=1")->execute([$file_name]);
            $success = "QR Updated!";
        }
    }
}

// Fetch Data
$set = $conn->query("SELECT * FROM settings WHERE id=1")->fetch();
$banners = $conn->query("SELECT * FROM banners ORDER BY id DESC")->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Settings - Admin</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="bg-gray-50 pb-24">

    <header class="bg-white p-4 flex items-center gap-4 sticky top-0 z-20 shadow-sm border-b md:hidden">
        <a href="index.php" class="text-gray-400"><i class="fas fa-arrow-left"></i></a>
        <h1 class="text-sm font-black tracking-widest text-gray-800 uppercase">Configuration</h1>
    </header>

    <main class="p-4 max-w-4xl mx-auto space-y-6">
        
        <?php if($success): ?>
            <div class="bg-green-600 text-white p-4 rounded-2xl text-xs font-bold uppercase shadow-lg">
                <i class="fas fa-check-circle mr-2"></i> <?= $success ?>
            </div>
        <?php endif; ?>

        <form method="POST" enctype="multipart/form-data" class="space-y-6">
            
            <div class="bg-white p-6 rounded-[2rem] shadow-sm border border-gray-100">
                <h3 class="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-4">Home Banners</h3>
                
                <div class="flex gap-2 mb-6">
                    <input type="file" name="banner_img" accept="image/*" class="flex-1 text-[10px] bg-gray-50 p-3 rounded-xl border border-dashed border-gray-200">
                    <button type="submit" class="bg-blue-600 text-white px-5 rounded-xl text-[10px] font-black uppercase">Add</button>
                </div>

                <div class="grid grid-cols-2 gap-3">
                    <?php foreach($banners as $b): ?>
                    <div class="relative rounded-2xl overflow-hidden border border-gray-100 aspect-video bg-gray-50">
                        <img src="../<?= $b['image'] ?>" class="w-full h-full object-cover">
                        <a href="?del_banner=<?= $b['id'] ?>" onclick="return confirm('Delete Banner?')" 
                           class="absolute top-2 right-2 w-7 h-7 bg-red-600 text-white rounded-full flex items-center justify-center shadow-lg">
                            <i class="fas fa-trash text-[10px]"></i>
                        </a>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>

            <div class="bg-white p-6 rounded-[2rem] shadow-sm border border-gray-100">
                <h3 class="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-4">Checkout Settings</h3>
                <div class="flex items-center justify-between p-4 bg-gray-50 rounded-2xl mb-6">
                    <span class="text-xs font-bold text-gray-700">Cash on Delivery (COD)</span>
                    <label class="relative inline-flex items-center cursor-pointer">
                        <input type="checkbox" name="cod_status" class="sr-only peer" <?= ($set['cod_status'] == 1) ? 'checked' : '' ?>>
                        <div class="w-11 h-6 bg-gray-200 rounded-full peer peer-checked:bg-red-600 after:content-[''] after:absolute after:top-0.5 after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:after:translate-x-full"></div>
                    </label>
                </div>

                <div class="space-y-3">
                    <?php foreach(['whatsapp', 'instagram'] as $f): ?>
                    <input type="text" name="<?= $f ?>" value="<?= $set[$f] ?? '' ?>" placeholder="<?= ucfirst($f) ?> Link" 
                           class="w-full bg-gray-50 border border-gray-100 p-4 rounded-2xl text-xs outline-none focus:border-red-500">
                    <?php endforeach; ?>
                </div>
            </div>

            <div class="bg-white p-6 rounded-[2rem] shadow-sm border border-gray-100 flex flex-col items-center">
                <h3 class="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-4 w-full">Payment QR</h3>
                <img src="../<?= $set['qr_code'] ?>" class="w-32 h-32 object-contain mb-4 border p-2 rounded-2xl bg-gray-50">
                <input type="file" name="qr_code_img" class="text-[10px] mb-4">
                <button type="submit" class="w-full bg-gray-900 text-white py-4 rounded-2xl font-black text-xs uppercase tracking-widest">Save Settings</button>
            </div>
        </form>
    </main>

    <nav class="fixed bottom-4 left-4 right-4 bg-gray-900/95 p-2 rounded-2xl shadow-2xl border border-white/10 flex justify-around md:hidden z-50">
        <a href="index.php" class="p-3 text-gray-400"><i class="fas fa-home"></i></a>
        <a href="categories.php" class="p-3 text-gray-400"><i class="fas fa-tags"></i></a>
        <a href="settings.php" class="p-3 text-red-500"><i class="fas fa-cog"></i></a>
    </nav>
</body>
</html>
