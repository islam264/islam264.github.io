<?php
if(!isset($_SESSION['admin_id'])) { header("Location: login.php"); exit; }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Admin - 7Cuts</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="bg-gray-100 flex h-screen">
    <aside class="w-64 bg-gray-900 text-white flex flex-col">
        <div class="p-4 text-2xl font-bold border-b border-gray-700">7Cuts Admin</div>
        <nav class="flex-1 p-4 space-y-2">
            <a href="index.php" class="block py-2 px-4 rounded hover:bg-gray-800">Dashboard</a>
            <a href="category.php" class="block py-2 px-4 rounded hover:bg-gray-800">Categories</a>
            <a href="product.php" class="block py-2 px-4 rounded hover:bg-gray-800">Products</a>
            <a href="order.php" class="block py-2 px-4 rounded hover:bg-gray-800">Orders</a>
        </nav>
        <a href="logout.php" class="p-4 bg-red-600 text-center">Logout</a>
    </aside>
    <main class="flex-1 overflow-y-auto p-8">
