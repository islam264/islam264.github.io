<?php
require '../common/config.php';

// Login Check
if(!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit;
}

// 1. Category Add Logic with Photo
if(isset($_POST['add_cat'])) {
    $name = trim($_POST['cat_name']);
    $image_path = "";

    // Image Upload Handling
    if(!empty($_FILES['cat_img']['name'])) {
        $target_dir = "../uploads/";
        $file_name = time() . "_" . basename($_FILES['cat_img']['name']);
        $target_file = $target_dir . $file_name;
        
        if(move_uploaded_file($_FILES['cat_img']['tmp_name'], $target_file)) {
            $image_path = "uploads/" . $file_name;
        }
    }

    if(!empty($name)){
        // Database mein name aur image dono save karein
        $stmt = $conn->prepare("INSERT INTO categories (name, cat_image) VALUES (?, ?)");
        $stmt->execute([$name, $image_path]);
        header("Location: categories.php?success=1");
        exit;
    }
}

// Delete Logic
if(isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $conn->query("DELETE FROM categories WHERE id=$id");
    header("Location: categories.php");
    exit;
}

$cats = $conn->query("SELECT * FROM categories ORDER BY id DESC")->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>Manage Categories - 7Cuts</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body { font-family: 'Inter', sans-serif; -webkit-tap-highlight-color: transparent; }
        .hide-scroll::-webkit-scrollbar { display: none; }
    </style>
</head>
<body class="bg-gray-50 flex h-screen overflow-hidden text-gray-900">

    <main class="flex-1 overflow-y-auto hide-scroll pb-24">
        
        <header class="md:hidden bg-white p-4 flex items-center gap-4 sticky top-0 z-20 shadow-sm border-b">
            <a href="index.php" class="text-gray-400"><i class="fas fa-arrow-left"></i></a>
            <h1 class="text-sm font-black tracking-widest text-gray-800 uppercase">Manage Categories</h1>
        </header>

        <div class="p-4 md:p-8 space-y-6">
            
            <?php if(isset($_GET['success'])): ?>
                <div class="bg-green-500 text-white p-3 rounded-xl text-[10px] font-bold uppercase flex items-center gap-2 shadow-lg">
                    <i class="fas fa-check-circle"></i> Category Added Successfully!
                </div>
            <?php endif; ?>

            <div class="bg-white p-4 rounded-2xl shadow-sm border border-gray-100">
                <h3 class="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-3">Add New Category</h3>
                <form method="POST" enctype="multipart/form-data" class="space-y-3">
                    <input type="text" name="cat_name" placeholder="Category Name..." required 
                        class="w-full bg-gray-50 border border-gray-100 p-3 rounded-xl text-xs font-bold outline-none focus:border-red-500 transition">
                    
                    <div class="flex items-center gap-2 bg-gray-50 p-2 rounded-xl border border-gray-100">
                        <i class="fas fa-image text-gray-400 ml-2"></i>
                        <input type="file" name="cat_img" accept="image/*" class="text-[10px] text-gray-500 flex-1">
                    </div>

                    <button type="submit" name="add_cat" 
                        class="w-full bg-red-600 text-white p-3 rounded-xl text-[10px] font-black uppercase tracking-widest active:scale-95 transition">
                        Add Category
                    </button>
                </form>
            </div>

            <section>
                <h3 class="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-3 px-1">All Categories (<?= count($cats) ?>)</h3>
                <div class="grid grid-cols-1 gap-2">
                    <?php foreach($cats as $c): ?>
                    <div class="bg-white px-4 py-3 rounded-xl shadow-sm border border-gray-100 flex justify-between items-center transition active:bg-gray-50">
                        <div class="flex items-center gap-3">
                            <div class="w-10 h-10 bg-gray-100 rounded-lg overflow-hidden flex items-center justify-center border border-gray-50">
                                <?php if(!empty($c['cat_image'])): ?>
                                    <img src="../<?= $c['cat_image'] ?>" class="w-full h-full object-cover">
                                <?php else: ?>
                                    <i class="fas fa-tag text-gray-300"></i>
                                <?php endif; ?>
                            </div>
                            <span class="text-xs font-black text-gray-700 uppercase tracking-tight"><?= htmlspecialchars($c['name']) ?></span>
                        </div>
                        <a href="?delete=<?= $c['id'] ?>" onclick="return confirm('Delete this category?')" 
                           class="w-8 h-8 flex items-center justify-center text-red-300 hover:text-red-600 transition">
                           <i class="fas fa-trash-alt text-[10px]"></i>
                        </a>
                    </div>
                    <?php endforeach; ?>
                </div>
            </section>

            <section class="fixed bottom-4 left-4 right-4 z-30">
                <div class="bg-gray-900/95 backdrop-blur-md p-2 rounded-2xl shadow-2xl border border-white/10 flex justify-around items-center">
                    <a href="index.php" class="p-3 text-gray-400 flex flex-col items-center"><i class="fas fa-home text-sm"></i></a>
                    <a href="product.php" class="p-3 text-gray-400 flex flex-col items-center"><i class="fas fa-plus text-sm"></i></a>
                    <a href="categories.php" class="p-3 text-red-500 flex flex-col items-center"><i class="fas fa-tags text-sm"></i></a>
                    <a href="order.php" class="p-3 text-gray-400 flex flex-col items-center"><i class="fas fa-shopping-bag text-sm"></i></a>
                    <a href="settings.php" class="p-3 text-gray-400 flex flex-col items-center"><i class="fas fa-cog text-sm"></i></a>
                </div>
            </section>

        </div>
    </main>
</body>
</html>
