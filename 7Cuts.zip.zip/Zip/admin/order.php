<?php
require '../common/config.php';

// Login Check
if(!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit;
}

// 1. HANDLE STATUS UPDATE
if(isset($_POST['update_status'])) {
    $oid = $_POST['order_id'];
    $status = $_POST['status'];
    $conn->prepare("UPDATE orders SET status=? WHERE id=?")->execute([$status, $oid]);
    header("Location: order.php");
    exit;
}

// 2. FETCH ALL ORDERS
$orders = $conn->query("SELECT * FROM orders ORDER BY id DESC")->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Orders - Admin</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="bg-gray-50 flex h-screen overflow-hidden font-sans">

    <aside class="w-64 bg-[#1a1c23] text-white hidden md:flex flex-col flex-shrink-0 transition-all duration-300">
        <div class="p-6 text-2xl font-black tracking-tighter text-center border-b border-gray-800">
            <span class="text-red-500">7</span>Cuts <span class="text-xs block font-normal text-gray-500">Admin Panel</span>
        </div>
        <nav class="flex-1 p-4 space-y-3 overflow-y-auto">
            <a href="index.php" class="flex items-center gap-4 py-3 px-4 rounded-xl text-gray-400 hover:bg-gray-800 hover:text-white transition">
                <i class="fas fa-th-large w-5"></i> <span>Dashboard</span>
            </a>
            <a href="order.php" class="flex items-center gap-4 py-3 px-4 rounded-xl bg-red-600 text-white shadow-lg shadow-red-600/30">
                <i class="fas fa-shopping-bag w-5"></i> <span class="font-bold">Orders</span>
            </a>
            <a href="product.php" class="flex items-center gap-4 py-3 px-4 rounded-xl text-gray-400 hover:bg-gray-800 hover:text-white transition">
                <i class="fas fa-box w-5"></i> <span>Products</span>
            </a>
            <a href="category.php" class="flex items-center gap-4 py-3 px-4 rounded-xl text-gray-400 hover:bg-gray-800 hover:text-white transition">
                <i class="fas fa-tags w-5"></i> <span>Categories</span>
            </a>
            <a href="banners.php" class="flex items-center gap-4 py-3 px-4 rounded-xl text-gray-400 hover:bg-gray-800 hover:text-white transition">
                <i class="fas fa-images w-5"></i> <span>Banners</span>
            </a>
        </nav>
    </aside>

    <main class="flex-1 flex flex-col h-screen overflow-hidden relative">
        
        <header class="bg-white shadow-sm p-4 flex justify-between items-center z-10 px-4 md:px-8">
            <div class="flex items-center gap-3">
                <a href="index.php" class="md:hidden w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center text-gray-600 active:scale-95">
                    <i class="fas fa-arrow-left"></i>
                </a>
                <h2 class="text-xl font-bold text-gray-800">All Orders</h2>
            </div>
            <div class="text-sm font-bold bg-red-50 text-red-600 px-3 py-1 rounded-lg border border-red-100">
                Total: <?= count($orders) ?>
            </div>
        </header>

        <div class="flex-1 overflow-y-auto p-4 md:p-6 pb-24">
            
            <div class="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
                
                <div class="overflow-x-auto">
                    <table class="w-full text-left text-sm whitespace-nowrap">
                        <thead class="bg-gray-50 text-gray-500">
                            <tr>
                                <th class="p-4 font-semibold">ID</th>
                                <th class="p-4 font-semibold">Customer</th>
                                <th class="p-4 font-semibold">Address</th>
                                <th class="p-4 font-semibold">Total</th>
                                <th class="p-4 font-semibold">Status</th>
                                <th class="p-4 font-semibold text-right">Action</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-gray-100">
                            <?php if(count($orders) > 0): ?>
                                <?php foreach($orders as $o): ?>
                                <tr class="hover:bg-gray-50 transition">
                                    <td class="p-4 font-mono text-gray-500 font-bold">#<?= $o['id'] ?></td>
                                    
                                    <td class="p-4">
                                        <div class="font-bold text-gray-800"><?= htmlspecialchars($o['name']) ?></div>
                                        <div class="text-xs text-gray-400"><i class="fas fa-phone mr-1"></i><?= $o['phone'] ?></div>
                                    </td>
                                    
                                    <td class="p-4 text-gray-600 max-w-xs truncate" title="<?= htmlspecialchars($o['address']) ?>">
                                        <?= htmlspecialchars($o['address']) ?>
                                    </td>
                                    
                                    <td class="p-4 font-bold text-gray-800">₹<?= number_format($o['total_amount']) ?></td>
                                    
                                    <td class="p-4">
                                        <form method="POST" class="inline-block">
                                            <input type="hidden" name="update_status" value="1">
                                            <input type="hidden" name="order_id" value="<?= $o['id'] ?>">
                                            <select name="status" onchange="this.form.submit()" class="
                                                border-none bg-transparent font-bold text-xs uppercase cursor-pointer focus:ring-0 py-1 pl-0 pr-6
                                                <?= $o['status']=='Pending'?'text-yellow-600':'' ?>
                                                <?= $o['status']=='Placed'?'text-blue-600':'' ?>
                                                <?= $o['status']=='Completed'?'text-green-600':'' ?>
                                                <?= $o['status']=='Cancelled'?'text-red-600':'' ?>
                                            ">
                                                <option value="Pending" <?= $o['status']=='Pending'?'selected':'' ?>>Pending</option>
                                                <option value="Placed" <?= $o['status']=='Placed'?'selected':'' ?>>Placed</option>
                                                <option value="Completed" <?= $o['status']=='Completed'?'selected':'' ?>>Completed</option>
                                                <option value="Cancelled" <?= $o['status']=='Cancelled'?'selected':'' ?>>Cancelled</option>
                                            </select>
                                        </form>
                                    </td>
                                    
                                    <td class="p-4 text-right">
                                        <a href="order_detail.php?id=<?= $o['id'] ?>" class="bg-blue-50 text-blue-600 px-3 py-1.5 rounded-lg text-xs font-bold hover:bg-blue-100 transition">
                                            View
                                        </a>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="6" class="p-10 text-center text-gray-400">
                                        <i class="fas fa-box-open text-3xl mb-3 opacity-30"></i>
                                        <p>No orders received yet.</p>
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>

        </div>
    </main>
</body>
</html>
