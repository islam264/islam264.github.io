<?php
require '../common/config.php';
if(!isset($_SESSION['admin_id'])) { header("Location: login.php"); exit; }

// Handle Update
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = $_POST['id'];
    $title = $_POST['title'];
    $content = $_POST['content'];

    $stmt = $conn->prepare("UPDATE policies SET title=?, content=? WHERE id=?");
    $stmt->execute([$title, $content, $id]);
    $success = "Policy Updated Successfully!";
}

// Fetch All Policies
$policies = $conn->query("SELECT * FROM policies")->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Policies - Admin</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="bg-gray-100 flex h-screen">

    <aside class="w-64 bg-gray-900 text-white hidden md:flex flex-col">
        <div class="p-6 text-2xl font-bold border-b border-gray-700">7Cuts Admin</div>
        <nav class="flex-1 p-4 space-y-2">
            <a href="index.php" class="block py-3 px-4 rounded text-gray-300 hover:bg-gray-800">Dashboard</a>
            <a href="policies.php" class="block py-3 px-4 rounded bg-red-600 text-white font-bold">Policies</a>
            <a href="../index.php" target="_blank" class="block py-3 px-4 mt-10 border-t border-gray-700 text-gray-400">Visit Site</a>
        </nav>
    </aside>

    <main class="flex-1 p-6 overflow-y-auto">
        <div class="md:hidden flex justify-between items-center mb-6">
            <h1 class="text-xl font-bold">Policies</h1>
            <a href="index.php" class="bg-gray-800 text-white px-3 py-1 rounded">Menu</a>
        </div>

        <h2 class="text-2xl font-bold mb-6 text-gray-800">Edit Website Policies</h2>

        <?php if(isset($success)) echo "<div class='bg-green-100 text-green-700 p-3 rounded mb-4'>$success</div>"; ?>

        <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
            
            <div class="md:col-span-1 bg-white rounded-lg shadow overflow-hidden h-fit">
                <div class="p-4 bg-gray-50 border-b font-bold">Select Page to Edit</div>
                <div class="divide-y">
                    <?php foreach($policies as $p): ?>
                    <button onclick="loadPolicy(<?= htmlspecialchars(json_encode($p)) ?>)" class="w-full text-left p-4 hover:bg-red-50 hover:text-red-600 focus:bg-red-50 focus:text-red-600 transition">
                        <i class="fas fa-file-alt mr-2 text-gray-400"></i> <?= $p['title'] ?>
                    </button>
                    <?php endforeach; ?>
                </div>
            </div>

            <div class="md:col-span-2 bg-white rounded-lg shadow p-6">
                <form method="POST" id="editForm">
                    <input type="hidden" name="id" id="p_id">
                    
                    <div class="mb-4">
                        <label class="block text-sm font-bold text-gray-700 mb-1">Page Title</label>
                        <input type="text" name="title" id="p_title" class="w-full border p-3 rounded bg-gray-50 font-bold text-lg" required>
                    </div>

                    <div class="mb-4">
                        <label class="block text-sm font-bold text-gray-700 mb-1">Page Content</label>
                        <textarea name="content" id="p_content" rows="15" class="w-full border p-3 rounded text-gray-700 leading-relaxed focus:ring-2 focus:ring-red-500 outline-none" required></textarea>
                        <p class="text-xs text-gray-400 mt-2">Tip: Use Enter key for new lines. HTML tags are allowed.</p>
                    </div>

                    <button type="submit" class="bg-red-600 text-white px-6 py-3 rounded font-bold hover:bg-red-700 shadow-md w-full md:w-auto">
                        Update Policy
                    </button>
                </form>
            </div>

        </div>
    </main>

    <script>
        // Load first policy by default
        const policies = <?= json_encode($policies) ?>;
        if(policies.length > 0) loadPolicy(policies[0]);

        function loadPolicy(data) {
            document.getElementById('p_id').value = data.id;
            document.getElementById('p_title').value = data.title;
            document.getElementById('p_content').value = data.content;
        }
    </script>
</body>
</html>
