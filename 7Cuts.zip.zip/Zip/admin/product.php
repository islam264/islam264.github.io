<?php
require '../common/config.php';

if(!isset($_SESSION['admin_id'])) { header("Location: login.php"); exit; }

// --- SMART IMAGE HELPER FOR ADMIN ---
function getAdminImg($dbPath) {
    $dbPath = trim($dbPath);
    if(empty($dbPath)) return "../assets/no-image.png"; // Placeholder
    
    // Agar path me already 'uploads/' hai
    if(strpos($dbPath, 'uploads/') === 0) {
        return "../" . $dbPath; 
    }
    // Agar path me 'http' hai (External Link)
    if(strpos($dbPath, 'http') === 0) {
        return $dbPath;
    }
    // Default: Purane products (sirf filename)
    return "../uploads/" . $dbPath;
}

// 1. ADD/EDIT
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $cat_id = $_POST['cat_id'];
    $price = $_POST['price'];
    $mrp = $_POST['mrp'];
    $sizes = $_POST['sizes'];
    $description = $_POST['description'];
    $stock = $_POST['stock'];
    
    $imagePathStr = isset($_POST['old_image']) ? $_POST['old_image'] : "";

    // Upload Logic
    if(isset($_FILES['images']) && count($_FILES['images']['name']) > 0 && !empty($_FILES['images']['name'][0])) {
        $uploadedFiles = [];
        $targetDir = "../uploads/";
        if(!is_dir($targetDir)) mkdir($targetDir, 0777, true);

        foreach($_FILES['images']['name'] as $key => $val) {
            $fileName = time() . "_" . basename($_FILES['images']['name'][$key]);
            if(move_uploaded_file($_FILES['images']['tmp_name'][$key], $targetDir . $fileName)) {
                // IMPORTANT: Save only 'uploads/filename.jpg' to be consistent
                $uploadedFiles[] = "uploads/" . $fileName;
            }
        }
        if(count($uploadedFiles) > 0) $imagePathStr = implode(',', $uploadedFiles);
    }

    if (isset($_POST['id']) && !empty($_POST['id'])) {
        $stmt = $conn->prepare("UPDATE products SET name=?, cat_id=?, price=?, mrp=?, sizes=?, description=?, image=?, stock=? WHERE id=?");
        $stmt->execute([$name, $cat_id, $price, $mrp, $sizes, $description, $imagePathStr, $stock, $_POST['id']]);
    } else {
        $stmt = $conn->prepare("INSERT INTO products (name, cat_id, price, mrp, sizes, description, image, stock) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute([$name, $cat_id, $price, $mrp, $sizes, $description, $imagePathStr, $stock]);
    }
    header("Location: product.php"); exit;
}

// 2. DELETE
if (isset($_GET['delete'])) {
    $conn->prepare("DELETE FROM products WHERE id=?")->execute([$_GET['delete']]);
    header("Location: product.php"); exit;
}

// 3. FETCH
$editProduct = null;
if (isset($_GET['edit'])) {
    $stmt = $conn->prepare("SELECT * FROM products WHERE id=?");
    $stmt->execute([$_GET['edit']]);
    $editProduct = $stmt->fetch();
}
$products = $conn->query("SELECT products.*, categories.name as cat_name FROM products LEFT JOIN categories ON products.cat_id = categories.id ORDER BY products.id DESC")->fetchAll();
$cats = $conn->query("SELECT * FROM categories")->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Products - Admin</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="bg-gray-100 flex h-screen overflow-hidden">

    <aside class="w-64 bg-gray-900 text-white hidden md:flex flex-col flex-shrink-0">
        <div class="p-6 text-2xl font-bold border-b border-gray-700">7Cuts Admin</div>
        <nav class="flex-1 p-4 space-y-2 overflow-y-auto">
            <a href="index.php" class="block py-3 px-4 rounded hover:bg-gray-800 text-gray-300">Dashboard</a>
            <a href="product.php" class="block py-3 px-4 rounded bg-red-600 text-white font-bold">Products</a>
            <a href="category.php" class="block py-3 px-4 rounded hover:bg-gray-800 text-gray-300">Categories</a>
            <a href="order.php" class="block py-3 px-4 rounded hover:bg-gray-800 text-gray-300">Orders</a>
            <a href="../index.php" target="_blank" class="block py-3 px-4 mt-6 border-t border-gray-700 text-gray-400">Visit Website</a>
        </nav>
    </aside>

    <main class="flex-1 flex flex-col h-screen overflow-hidden">
        <header class="bg-white shadow p-4 flex justify-between items-center z-10">
            <h2 class="text-xl font-bold text-gray-800">Manage Products</h2>
            <a href="product.php" class="text-blue-600 font-bold text-sm">Refresh</a>
        </header>

        <div class="flex-1 overflow-y-auto p-6">
            
            <div class="bg-white p-6 rounded-xl shadow-sm border mb-8">
                <h3 class="font-bold mb-4"><?= $editProduct ? 'Edit Product' : 'Add New Product' ?></h3>
                <form method="POST" enctype="multipart/form-data" class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <input type="hidden" name="id" value="<?= $editProduct['id'] ?? '' ?>">
                    <input type="hidden" name="old_image" value="<?= $editProduct['image'] ?? '' ?>">

                    <input type="text" name="name" value="<?= $editProduct['name'] ?? '' ?>" placeholder="Product Name" required class="border p-2 rounded">
                    <select name="cat_id" class="border p-2 rounded">
                        <?php foreach($cats as $c): ?>
                            <option value="<?= $c['id'] ?>" <?= ($editProduct && $editProduct['cat_id']==$c['id'])?'selected':'' ?>><?= $c['name'] ?></option>
                        <?php endforeach; ?>
                    </select>
                    <input type="number" name="price" value="<?= $editProduct['price'] ?? '' ?>" placeholder="Price" required class="border p-2 rounded">
                    <input type="number" name="mrp" value="<?= $editProduct['mrp'] ?? '' ?>" placeholder="MRP" class="border p-2 rounded">
                    <input type="text" name="sizes" value="<?= $editProduct['sizes'] ?? '' ?>" placeholder="Sizes (e.g. 28,30,32)" class="border p-2 rounded">
                    <select name="stock" class="border p-2 rounded">
                        <option value="1" <?= ($editProduct && $editProduct['stock']==1)?'selected':'' ?>>In Stock</option>
                        <option value="0" <?= ($editProduct && $editProduct['stock']==0)?'selected':'' ?>>Out of Stock</option>
                    </select>

                    <div class="md:col-span-2">
                        <label class="block text-xs font-bold text-gray-500 mb-1">Images (Select Multiple)</label>
                        <input type="file" name="images[]" multiple class="w-full border p-2 rounded bg-gray-50" accept="image/*">
                        <?php if($editProduct && !empty($editProduct['image'])): $imgs = explode(',', $editProduct['image']); ?>
                        <div class="flex gap-2 mt-2 overflow-x-auto">
                            <?php foreach($imgs as $img): ?>
                                <img src="<?= getAdminImg($img) ?>" class="w-16 h-16 object-cover rounded border">
                            <?php endforeach; ?>
                        </div>
                        <?php endif; ?>
                    </div>

                    <textarea name="description" rows="3" placeholder="Description" class="md:col-span-2 border p-2 rounded"><?= $editProduct['description'] ?? '' ?></textarea>

                    <div class="md:col-span-2">
                        <button type="submit" class="bg-red-600 text-white px-6 py-2 rounded font-bold hover:bg-red-700 w-full md:w-auto">Save Product</button>
                    </div>
                </form>
            </div>

            <div class="bg-white rounded-xl shadow-sm border overflow-hidden">
                <table class="w-full text-left">
                    <thead class="bg-gray-50 text-gray-500 text-xs uppercase">
                        <tr><th class="p-4">Image</th><th class="p-4">Name</th><th class="p-4">Price</th><th class="p-4 text-right">Action</th></tr>
                    </thead>
                    <tbody class="divide-y divide-gray-100 text-sm">
                        <?php foreach($products as $p): 
                            $imgArr = explode(',', $p['image']); 
                        ?>
                        <tr class="hover:bg-gray-50">
                            <td class="p-4">
                                <img src="<?= getAdminImg($imgArr[0]) ?>" class="w-12 h-12 rounded object-cover border bg-gray-100">
                            </td>
                            <td class="p-4 font-bold text-gray-700">
                                <?= $p['name'] ?>
                                <span class="block text-xs font-normal text-gray-400"><?= $p['cat_name'] ?></span>
                            </td>
                            <td class="p-4 font-bold">₹<?= $p['price'] ?></td>
                            <td class="p-4 text-right">
                                <a href="?edit=<?= $p['id'] ?>" class="text-blue-600 hover:text-blue-800 mr-3"><i class="fas fa-edit"></i></a>
                                <a href="?delete=<?= $p['id'] ?>" onclick="return confirm('Delete?')" class="text-red-600 hover:text-red-800"><i class="fas fa-trash"></i></a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

        </div>
    </main>
</body>
</html>
