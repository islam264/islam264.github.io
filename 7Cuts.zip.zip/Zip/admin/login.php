<?php
require '../common/config.php';

// Already Logged in check
if(isset($_SESSION['admin_id'])) {
    header("Location: index.php");
    exit;
}

if($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user = $_POST['username'];
    $pass = $_POST['password'];
    
    $stmt = $conn->prepare("SELECT * FROM admin WHERE username=?");
    $stmt->execute([$user]);
    $admin = $stmt->fetch();
    
    if($admin && password_verify($pass, $admin['password'])) {
        $_SESSION['admin_id'] = $admin['id'];
        header("Location: index.php");
        exit;
    } else {
        $error = "Incorrect Username or Password";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>Admin Login - 7Cuts</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="bg-gray-900 flex items-center justify-center min-h-screen px-4">
    
    <div class="bg-white w-full max-w-sm rounded-xl shadow-2xl overflow-hidden transform transition-all">
        
        <div class="bg-gray-50 p-6 text-center border-b">
            <h2 class="text-2xl font-bold text-gray-800 tracking-tight">Admin Panel</h2>
            <p class="text-gray-500 text-sm mt-1">Secure Login</p>
        </div>

        <div class="p-6">
            <form method="POST" class="space-y-5">
                
                <?php if(isset($error)): ?>
                    <div class="bg-red-50 border border-red-200 text-red-600 text-sm p-3 rounded-lg text-center font-medium animate-pulse">
                        <i class="fas fa-exclamation-circle mr-1"></i> <?= $error ?>
                    </div>
                <?php endif; ?>

                <div>
                    <label class="block text-xs font-bold text-gray-600 uppercase mb-1">Username</label>
                    <div class="relative">
                        <span class="absolute inset-y-0 left-0 pl-3 flex items-center text-gray-400">
                            <i class="fas fa-user"></i>
                        </span>
                        <input type="text" name="username" 
                               class="w-full pl-10 pr-4 py-3 bg-gray-50 border border-gray-200 rounded-lg focus:outline-none focus:bg-white focus:ring-2 focus:ring-blue-500 transition" 
                               placeholder="Enter username" required>
                    </div>
                </div>

                <div>
                    <label class="block text-xs font-bold text-gray-600 uppercase mb-1">Password</label>
                    <div class="relative">
                        <span class="absolute inset-y-0 left-0 pl-3 flex items-center text-gray-400">
                            <i class="fas fa-lock"></i>
                        </span>
                        <input type="password" name="password" 
                               class="w-full pl-10 pr-4 py-3 bg-gray-50 border border-gray-200 rounded-lg focus:outline-none focus:bg-white focus:ring-2 focus:ring-blue-500 transition" 
                               placeholder="••••••••" required>
                    </div>
                </div>

                <button type="submit" class="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-3.5 rounded-lg shadow-md transition-transform transform active:scale-95">
                    LOGIN DASHBOARD
                </button>
            </form>
        </div>

        <div class="bg-gray-50 p-4 text-center">
            <a href="../index.php" class="text-sm text-gray-500 hover:text-blue-600 font-medium transition">
                <i class="fas fa-arrow-left mr-1"></i> Back to Website
            </a>
        </div>
    </div>

</body>
</html>
