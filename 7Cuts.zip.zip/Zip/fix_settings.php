<?php
// Is file ko 'Uzra' folder mein save karein
require 'common/config.php';

try {
    echo "<h2>⚙️ Creating Settings Table...</h2>";

    // 1. Settings Table Banana
    $sql = "CREATE TABLE IF NOT EXISTS settings (
        id INT AUTO_INCREMENT PRIMARY KEY,
        whatsapp VARCHAR(255) DEFAULT '',
        instagram VARCHAR(255) DEFAULT '',
        facebook VARCHAR(255) DEFAULT '',
        youtube VARCHAR(255) DEFAULT ''
    )";
    $conn->exec($sql);
    echo "<p style='color:green'>✅ Settings Table Created Successfully.</p>";

    // 2. Default Data Insert Karna
    // Check karein agar data pehle se hai to duplicate na ho
    $stmt = $conn->query("SELECT * FROM settings WHERE id=1");
    if($stmt->rowCount() == 0) {
        $conn->exec("INSERT INTO settings (id, whatsapp, instagram, facebook, youtube) VALUES (1, '', '', '', '')");
        echo "<p style='color:blue'>✅ Default Empty Row Added.</p>";
    } else {
        echo "<p style='color:orange'>ℹ️ Table already has data.</p>";
    }

    echo "<hr><h3>🎉 Fix Complete!</h3>";
    echo "<a href='admin/setting.php' style='background:green; color:white; padding:15px 30px; text-decoration:none; border-radius:5px;'>Go to Settings Page</a>";

} catch(PDOException $e) {
    echo "<h3 style='color:red'>Error: " . $e->getMessage() . "</h3>";
}
?>
