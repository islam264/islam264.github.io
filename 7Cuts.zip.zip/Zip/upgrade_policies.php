<?php
require 'common/config.php';

try {
    echo "<h2>⚙️ Setting up Dynamic Policies...</h2>";

    // 1. Table Banana
    $conn->exec("CREATE TABLE IF NOT EXISTS policies (
        id INT AUTO_INCREMENT PRIMARY KEY,
        slug VARCHAR(50) UNIQUE,
        title VARCHAR(255),
        content TEXT
    )");
    echo "✅ Policies Table Created.<br>";

    // 2. Default Policies Insert Karna
    $defaults = [
        'privacy' => ['Privacy Policy', 'We value your trust. This policy describes how we handle your data...'],
        'terms' => ['Terms & Conditions', 'By using our website, you agree to the following terms...'],
        'refund' => ['Refund Policy', 'Refunds are processed within 5-7 days for valid cases...'],
        'shipping' => ['Shipping Policy', 'We deliver within 90 minutes in select areas...'],
        'contact' => ['Contact Us', 'Address: Shop 7, Delhi.\nPhone: +91 9876543210\nEmail: support@7cuts.com']
    ];

    $stmt = $conn->prepare("INSERT IGNORE INTO policies (slug, title, content) VALUES (?, ?, ?)");
    
    foreach ($defaults as $slug => $data) {
        $stmt->execute([$slug, $data[0], $data[1]]);
    }
    echo "✅ Default Content Inserted.<br>";

    echo "<hr><h3>🎉 Done!</h3> <a href='admin/policies.php'>Go to Admin Policy Manager</a>";

} catch(PDOException $e) {
    echo "Error: " . $e->getMessage();
}
?>
