<?php
require 'common/config.php';

try {
    echo "<h2>⚙️ Adding QR Code Column...</h2>";

    // Settings table mein 'qr_code' column add karne ki SQL query
    $sql = "ALTER TABLE settings ADD COLUMN qr_code VARCHAR(255) DEFAULT 'assets/my_qr.jpg'";
    
    $conn->exec($sql);
    
    echo "<h3 style='color:green'>✅ Success! Column 'qr_code' added successfully.</h3>";
    echo "<p>Ab aapka checkout page bina error ke khulega.</p>";
    echo "<br><a href='cart.php' style='padding:10px; background:red; color:white; text-decoration:none;'>Go back to Cart</a>";

} catch(PDOException $e) {
    echo "<h3 style='color:red'>Error: " . $e->getMessage() . "</h3>";
    echo "<p>Check if the column already exists or if the table name 'settings' is correct.</p>";
}
?>
