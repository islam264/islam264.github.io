<?php
// Is file ko 'Uzra' folder me save karein
require 'common/config.php';

echo "<h2>⚙️ Fixing Database Columns...</h2>";

try {
    // 1. MRP Column Add Karna
    // Check karte hain agar column nahi hai tabhi add karein
    try {
        $conn->exec("SELECT mrp FROM products LIMIT 1");
        echo "<p style='color:orange'>ℹ️ MRP column pehle se hai.</p>";
    } catch (Exception $e) {
        $conn->exec("ALTER TABLE products ADD COLUMN mrp DECIMAL(10,2) DEFAULT 0 AFTER price");
        echo "<p style='color:green'>✅ MRP column added successfully!</p>";
    }

    // 2. Sizes Column Add Karna
    try {
        $conn->exec("SELECT sizes FROM products LIMIT 1");
        echo "<p style='color:orange'>ℹ️ Sizes column pehle se hai.</p>";
    } catch (Exception $e) {
        $conn->exec("ALTER TABLE products ADD COLUMN sizes VARCHAR(255) DEFAULT '' AFTER description");
        echo "<p style='color:green'>✅ Sizes column added successfully!</p>";
    }

    // 3. Gallery Table Banana
    $sql = "CREATE TABLE IF NOT EXISTS product_gallery (
        id INT AUTO_INCREMENT PRIMARY KEY,
        product_id INT,
        image VARCHAR(255)
    )";
    $conn->exec($sql);
    echo "<p style='color:green'>✅ Product Gallery table checked/created.</p>";

    echo "<hr><h3>🎉 Fix Complete!</h3>";
    echo "<a href='admin/product.php' style='background:blue; color:white; padding:10px 20px; text-decoration:none;'>Go back to Add Product</a>";

} catch(PDOException $e) {
    echo "<h3 style='color:red'>Error: " . $e->getMessage() . "</h3>";
}
?>
