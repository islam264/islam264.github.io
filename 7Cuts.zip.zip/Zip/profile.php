<?php
require 'common/config.php';

// Check Login
if(!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

// Handle Logout
if(isset($_GET['logout'])) {
    session_destroy();
    header("Location: login.php");
    exit;
}

// Fetch Social Media Settings
$social = [];
try {
    $stmt = $conn->query("SELECT * FROM settings WHERE id=1");
    $social = $stmt->fetch(PDO::FETCH_ASSOC);
} catch(Exception $e) {}

include 'common/header.php';
?>

<style>
    /* Animation Styles */
    .reveal-element { opacity: 0; transform: translateY(20px); transition: opacity 0.6s ease-out, transform 0.6s ease-out; }
    .reveal-element.visible { opacity: 1; transform: translateY(0); }
</style>

<div class="bg-cream min-h-screen pb-24">
    <div class="container mx-auto px-4 pt-6">
        
        <div class="reveal-element bg-white p-6 rounded-xl shadow-sm border border-[#F0E6D2] text-center mb-6">
            <div class="w-24 h-24 bg-[#FEF8E6] rounded-full mx-auto flex items-center justify-center text-red-700 text-4xl font-black mb-3 border-4 border-white shadow-sm ring-1 ring-[#F0E6D2]">
                <?= strtoupper(substr($_SESSION['user_name'],0,1)) ?>
            </div>
            <h2 class="text-xl font-black text-[#4A3B32]"><?= htmlspecialchars($_SESSION['user_name']) ?></h2>
            <p class="text-xs text-gray-400 font-bold uppercase tracking-wider mt-1">Premium Member</p>
        </div>

        <div class="reveal-element bg-white rounded-xl shadow-sm border border-[#F0E6D2] overflow-hidden mb-6" style="transition-delay: 100ms;">
            
            <a href="order.php" class="flex items-center p-4 border-b border-[#F0E6D2] hover:bg-[#FEF8E6] transition group">
                <div class="w-9 h-9 rounded-full bg-blue-50 text-blue-600 flex items-center justify-center mr-4 group-hover:scale-110 transition">
                    <i class="fas fa-box"></i>
                </div>
                <span class="font-bold text-[#5D4037] flex-1">My Orders</span>
                <i class="fas fa-chevron-right text-gray-300 text-xs"></i>
            </a>

            <a href="policies.php?page=contact" class="flex items-center p-4 border-b border-[#F0E6D2] hover:bg-[#FEF8E6] transition group">
                <div class="w-9 h-9 rounded-full bg-green-50 text-green-600 flex items-center justify-center mr-4 group-hover:scale-110 transition">
                    <i class="fas fa-headset"></i>
                </div>
                <span class="font-bold text-[#5D4037] flex-1">Help & Support</span>
                <i class="fas fa-chevron-right text-gray-300 text-xs"></i>
            </a>

            <a href="policies.php?page=privacy" class="flex items-center p-4 border-b border-[#F0E6D2] hover:bg-[#FEF8E6] transition group">
                <div class="w-9 h-9 rounded-full bg-purple-50 text-purple-600 flex items-center justify-center mr-4 group-hover:scale-110 transition">
                    <i class="fas fa-shield-alt"></i>
                </div>
                <span class="font-bold text-[#5D4037] flex-1">Privacy & Policies</span>
                <i class="fas fa-chevron-right text-gray-300 text-xs"></i>
            </a>

            <a href="policies.php?page=shipping" class="flex items-center p-4 hover:bg-[#FEF8E6] transition group">
                <div class="w-9 h-9 rounded-full bg-orange-50 text-orange-600 flex items-center justify-center mr-4 group-hover:scale-110 transition">
                    <i class="fas fa-truck"></i>
                </div>
                <span class="font-bold text-[#5D4037] flex-1">Shipping Info</span>
                <i class="fas fa-chevron-right text-gray-300 text-xs"></i>
            </a>

        </div>

        <div class="reveal-element" style="transition-delay: 200ms;">
            <a href="?logout=true" class="block w-full py-4 bg-white border border-red-100 text-red-600 rounded-xl font-black text-center hover:bg-red-600 hover:text-white transition shadow-sm active:scale-95">
                <i class="fas fa-sign-out-alt mr-2"></i> Logout
            </a>
        </div>

        <?php if($social): ?>
        <div class="mt-8 text-center reveal-element" style="transition-delay: 300ms;">
            <p class="text-gray-400 text-[10px] font-bold mb-4 uppercase tracking-widest">Follow Us On</p>
            <div class="flex justify-center gap-4">
                
                <?php if(!empty($social['whatsapp'])): ?>
                <a href="https://wa.me/<?= $social['whatsapp'] ?>" target="_blank" class="w-12 h-12 rounded-full bg-white border border-green-100 text-green-600 flex items-center justify-center text-2xl shadow-sm hover:scale-110 hover:bg-green-600 hover:text-white transition duration-300">
                    <i class="fab fa-whatsapp"></i>
                </a>
                <?php endif; ?>

                <?php if(!empty($social['instagram'])): ?>
                <a href="<?= $social['instagram'] ?>" target="_blank" class="w-12 h-12 rounded-full bg-white border border-pink-100 text-pink-600 flex items-center justify-center text-xl shadow-sm hover:scale-110 hover:bg-pink-600 hover:text-white transition duration-300">
                    <i class="fab fa-instagram"></i>
                </a>
                <?php endif; ?>

                <?php if(!empty($social['facebook'])): ?>
                <a href="<?= $social['facebook'] ?>" target="_blank" class="w-12 h-12 rounded-full bg-white border border-blue-100 text-blue-600 flex items-center justify-center text-xl shadow-sm hover:scale-110 hover:bg-blue-600 hover:text-white transition duration-300">
                    <i class="fab fa-facebook-f"></i>
                </a>
                <?php endif; ?>

                <?php if(!empty($social['youtube'])): ?>
                <a href="<?= $social['youtube'] ?>" target="_blank" class="w-12 h-12 rounded-full bg-white border border-red-100 text-red-600 flex items-center justify-center text-xl shadow-sm hover:scale-110 hover:bg-red-600 hover:text-white transition duration-300">
                    <i class="fab fa-youtube"></i>
                </a>
                <?php endif; ?>

            </div>
        </div>
        <?php endif; ?>

        <p class="text-center text-[10px] text-gray-400 mt-8 mb-4 reveal-element" style="transition-delay: 400ms;">App Version 1.0.0</p>
    </div>
</div>

<script>
    // Trigger Animations
    document.addEventListener("DOMContentLoaded", function() {
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('visible');
                    observer.unobserve(entry.target); 
                }
            });
        }, { threshold: 0.1 });
        document.querySelectorAll('.reveal-element').forEach(el => observer.observe(el));
    });
</script>

<?php include 'common/bottom.php'; ?>
