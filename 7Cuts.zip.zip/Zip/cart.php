<?php
ob_start(); 
require 'common/config.php';

// --- 1. ADD TO CART LOGIC ---
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action']) && $_POST['action'] == 'add') {
    $pid = intval($_POST['pid']);
    $qty = isset($_POST['qty']) ? intval($_POST['qty']) : 1;
    if (!isset($_SESSION['cart'])) { $_SESSION['cart'] = []; }
    if (isset($_SESSION['cart'][$pid])) { $_SESSION['cart'][$pid] += $qty; } 
    else { $_SESSION['cart'][$pid] = $qty; }
    echo json_encode(['success' => true, 'total_items' => array_sum($_SESSION['cart'])]);
    exit; 
}

// --- 2. REMOVE FROM CART LOGIC ---
if(isset($_GET['remove'])) {
    $pid = $_GET['remove'];
    unset($_SESSION['cart'][$pid]);
    header("Location: cart.php");
    exit;
}

include 'common/header.php';

if(!isset($_SESSION['user_id'])) {
    echo "<script>alert('Please Login first!'); window.location.href='login.php';</script>";
    exit;
}

// --- 3. FETCH DATA ---
$total = 0;
$cartItems = [];
if(isset($_SESSION['cart']) && !empty($_SESSION['cart'])) {
    $ids = implode(',', array_keys($_SESSION['cart']));
    if(!empty($ids)) {
        $stmt = $conn->query("SELECT * FROM products WHERE id IN ($ids)");
        $cartItems = $stmt->fetchAll();
    }
}

foreach($cartItems as $c) {
    $qty = $_SESSION['cart'][$c['id']];
    $total += $c['price'] * $qty;
}

$uid = $_SESSION['user_id'];
$user = $conn->query("SELECT * FROM users WHERE id=$uid")->fetch();

// --- 4. FETCH APP SETTINGS (QR & COD Status) ---
$liveQR = 'assets/my_qr.jpg'; 
$isCodEnabled = true; // Default

try {
    $appSettings = $conn->query("SELECT qr_code, cod_status FROM settings WHERE id = 1")->fetch();
    if($appSettings) {
        if(!empty($appSettings['qr_code'])) { $liveQR = $appSettings['qr_code']; }
        // Admin toggle check
        $isCodEnabled = ($appSettings['cod_status'] == 1);
    }
} catch (Exception $e) { }
?>

<div class="bg-gray-50 min-h-screen pb-32">
    <div class="bg-white p-4 shadow-sm flex items-center gap-3 sticky top-0 z-10 border-b">
        <a href="index.php" class="text-gray-600"><i class="fas fa-arrow-left"></i></a>
        <h2 class="text-lg font-bold">Checkout</h2>
    </div>

    <?php if(empty($cartItems)): ?>
        <div class="flex flex-col items-center justify-center h-[80vh] text-gray-400 text-center px-4">
            <i class="fas fa-shopping-basket text-6xl mb-4 text-gray-200"></i>
            <p class="font-bold">Your cart is empty.</p>
            <a href="index.php" class="mt-4 bg-red-600 text-white px-8 py-3 rounded-full font-bold shadow-lg">Start Shopping</a>
        </div>
    <?php else: ?>

        <form id="orderForm" action="place_order.php" method="POST" class="p-4 space-y-5">
            <input type="hidden" name="total_amount" value="<?= $total ?>">
            <input type="hidden" name="payment_method" id="payment_method" value="UPI">

            <div class="bg-white p-4 rounded-xl shadow-sm border border-gray-100">
                <h3 class="font-bold text-gray-800 mb-3 text-xs uppercase tracking-tight">Order Summary</h3>
                <?php foreach($cartItems as $p): $qty = $_SESSION['cart'][$p['id']]; ?>
                    <div class="flex justify-between text-sm py-3 border-b border-gray-50 last:border-0">
                        <div class="flex items-center gap-3">
                            <div class="w-14 h-14 bg-white rounded-lg border flex items-center justify-center overflow-hidden">
                                <?php 
                                    $imgName = trim($p['image']);
                                    if (strpos($imgName, ',') !== false) { $imgArray = explode(',', $imgName); $imgName = trim($imgArray[0]); }
                                    $finalPath = (strpos($imgName, 'uploads/') === false && strpos($imgName, 'http') === false) ? 'uploads/'.$imgName : $imgName;
                                ?>
                                <img src="<?= $finalPath ?>" class="max-w-full max-h-full object-contain" onerror="this.src='https://placehold.co/100x100?text=No+Image'">
                            </div>
                            <div>
                                <span class="font-bold text-gray-800 block text-sm"><?= htmlspecialchars($p['name']) ?></span>
                                <span class="text-gray-400 text-[10px] font-bold">Qty: <?= $qty ?> × ₹<?= number_format($p['price']) ?></span>
                            </div>
                        </div>
                        <div class="flex items-center gap-4">
                            <span class="font-black text-gray-900">₹<?= number_format($p['price'] * $qty) ?></span>
                            <a href="?remove=<?= $p['id'] ?>" class="w-7 h-7 bg-red-50 text-red-500 rounded-full flex items-center justify-center transition hover:bg-red-500 hover:text-white">
                                <i class="fas fa-trash-alt text-[10px]"></i>
                            </a>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>

            <div class="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 space-y-5">
                <h3 class="font-bold text-gray-800 uppercase tracking-tight text-sm border-b pb-3 text-blue-600">Billing Details</h3>
                <div>
                    <label class="block text-[10px] font-bold text-gray-500 mb-1 uppercase tracking-widest">Full Name *</label>
                    <input type="text" name="name" value="<?= htmlspecialchars($user['name']) ?>" required class="w-full px-4 py-3 rounded-xl border border-gray-200 outline-none text-sm">
                </div>
                <div>
                    <label class="block text-[10px] font-bold text-gray-500 mb-1 uppercase tracking-widest">Street address *</label>
                    <input type="text" name="address" placeholder="House number and street name" required class="w-full px-4 py-3 rounded-xl border border-gray-200 outline-none text-sm">
                </div>
                <div class="grid grid-cols-2 gap-3">
                    <input type="text" name="city" placeholder="City *" required class="w-full px-4 py-3 rounded-xl border border-gray-200 text-sm">
                    <input type="number" name="pincode" placeholder="PIN Code *" required class="w-full px-4 py-3 rounded-xl border border-gray-200 text-sm">
                </div>
                <input type="tel" name="phone" value="<?= htmlspecialchars($user['phone']) ?>" required class="w-full px-4 py-3 rounded-xl border border-gray-200 text-sm">
            </div>

            <div class="bg-white p-4 rounded-xl shadow-sm border border-gray-100">
                <h3 class="font-bold text-gray-800 mb-3 text-sm uppercase tracking-tight">Payment Method</h3>
                
                <div class="flex gap-2 mb-4">
                    <button type="button" onclick="setPayment('UPI')" id="btn-upi" class="flex-1 py-3 border-2 border-red-600 bg-red-50 text-red-700 font-bold rounded-xl text-sm transition">UPI / QR Scan</button>
                    
                    <?php if($isCodEnabled): ?>
                        <button type="button" onclick="setPayment('COD')" id="btn-cod" class="flex-1 py-3 border border-gray-200 text-gray-500 font-bold rounded-xl text-sm transition">Cash (COD)</button>
                    <?php else: ?>
                        <div class="flex-1 py-3 bg-gray-50 border border-dashed border-gray-200 text-gray-400 font-bold rounded-xl text-[10px] flex items-center justify-center uppercase">COD Off</div>
                    <?php endif; ?>
                </div>

                <div id="qr-section" class="text-center bg-gray-50 p-4 rounded-xl border-2 border-dashed border-gray-200">
                    <p class="text-[10px] text-gray-400 mb-3 uppercase font-bold tracking-widest">Scan QR to pay <span class="text-gray-900 font-black">₹<?= number_format($total) ?></span></p>
                    <img src="<?= $liveQR ?>" class="w-44 h-44 mx-auto rounded-lg shadow-md mb-4 border-4 border-white">
                    <input type="text" name="txn_id" id="txn_id" placeholder="Transaction ID (UTR)" class="w-full p-3 border border-gray-200 rounded-lg text-sm outline-none bg-white">
                </div>

                <div id="cod-section" class="hidden text-center p-6 bg-blue-50 rounded-xl border border-blue-100">
                    <i class="fas fa-truck-loading text-blue-500 text-3xl mb-2"></i>
                    <p class="text-sm font-bold text-blue-800">Cash on Delivery Enabled</p>
                </div>
            </div>

            <div class="fixed bottom-0 left-0 w-full bg-white p-4 border-t z-50">
                <button type="button" onclick="confirmOrder()" class="w-full bg-red-600 text-white font-black text-lg py-4 rounded-2xl shadow-lg uppercase tracking-widest">
                    Confirm Order
                </button>
            </div>
        </form>
    <?php endif; ?>
</div>

<script>
function setPayment(mode) {
    const upiSection = document.getElementById('qr-section');
    const codSection = document.getElementById('cod-section');
    const upiBtn = document.getElementById('btn-upi');
    const codBtn = document.getElementById('btn-cod');
    const methodInput = document.getElementById('payment_method');
    const txnInput = document.getElementById('txn_id');

    methodInput.value = mode;

    if(mode === 'UPI') {
        upiSection.classList.remove('hidden');
        codSection.classList.add('hidden');
        upiBtn.className = "flex-1 py-3 border-2 border-red-600 bg-red-50 text-red-700 font-bold rounded-xl text-sm transition";
        if(codBtn) codBtn.className = "flex-1 py-3 border border-gray-200 text-gray-500 font-bold rounded-xl text-sm transition";
        txnInput.required = true;
    } else {
        upiSection.classList.add('hidden');
        codSection.classList.remove('hidden');
        codBtn.className = "flex-1 py-3 border-2 border-blue-600 bg-blue-50 text-blue-700 font-bold rounded-xl text-sm transition";
        upiBtn.className = "flex-1 py-3 border border-gray-200 text-gray-500 font-bold rounded-xl text-sm transition";
        txnInput.required = false;
    }
}

function confirmOrder() {
    const form = document.getElementById('orderForm');
    if(!form.checkValidity()) { form.reportValidity(); return; }
    
    const method = document.getElementById('payment_method').value;
    if(method === 'UPI' && document.getElementById('txn_id').value.trim() === "") {
        alert("Please enter Transaction ID!"); return;
    }

    if(confirm("Confirm this order?")) { form.submit(); }
}
</script>
